import AsyncStorage from "@react-native-async-storage/async-storage";
import React, { createContext, useCallback, useContext, useEffect, useState } from "react";

interface AppLimit {
  appId: string;
  limitMinutes: number;
  enabled: boolean;
}

export type StrikeStatus = "safe" | "caution" | "danger";

interface FocusContextValue {
  isFocusModeActive: boolean;
  blurEnabled: boolean;
  globalLimitMinutes: number;
  appLimits: AppLimit[];
  currentStreak: number;
  strikePoints: number;
  strikePointsToday: number;
  strikeStatus: StrikeStatus;
  extraMinutesUnlocked: number;
  toggleFocusMode: () => void;
  toggleBlur: () => void;
  setGlobalLimit: (minutes: number) => void;
  setAppLimit: (appId: string, minutes: number, enabled: boolean) => void;
  spendStrikePoints: (cost: number) => boolean;
}

const FocusContext = createContext<FocusContextValue | null>(null);
const STORAGE_KEY = "@blurguard_focus_v2";

const defaultAppLimits: AppLimit[] = [
  { appId: "1", limitMinutes: 60, enabled: true },
  { appId: "2", limitMinutes: 120, enabled: false },
  { appId: "3", limitMinutes: 60, enabled: false },
  { appId: "4", limitMinutes: 60, enabled: false },
  { appId: "5", limitMinutes: 60, enabled: false },
  { appId: "6", limitMinutes: 60, enabled: false },
];

function computeStatus(usageMinutes: number, limitMinutes: number): StrikeStatus {
  const pct = (usageMinutes / limitMinutes) * 100;
  if (pct < 70) return "safe";
  if (pct < 100) return "caution";
  return "danger";
}

export function FocusProvider({ children }: { children: React.ReactNode }) {
  const [isFocusModeActive, setIsFocusModeActive] = useState(false);
  const [blurEnabled, setBlurEnabled] = useState(true);
  const [globalLimitMinutes, setGlobalLimitMinutes] = useState(120);
  const [appLimits, setAppLimits] = useState<AppLimit[]>(defaultAppLimits);
  const [currentStreak] = useState(7);
  const [strikePoints, setStrikePoints] = useState(420);
  const [strikePointsToday] = useState(34);
  const [extraMinutesUnlocked, setExtraMinutesUnlocked] = useState(0);

  const strikeStatus: StrikeStatus = computeStatus(342, globalLimitMinutes);

  useEffect(() => {
    AsyncStorage.getItem(STORAGE_KEY).then((raw) => {
      if (!raw) return;
      try {
        const data = JSON.parse(raw);
        if (data.isFocusModeActive !== undefined) setIsFocusModeActive(data.isFocusModeActive);
        if (data.blurEnabled !== undefined) setBlurEnabled(data.blurEnabled);
        if (data.globalLimitMinutes) setGlobalLimitMinutes(data.globalLimitMinutes);
        if (data.appLimits) setAppLimits(data.appLimits);
        if (data.strikePoints) setStrikePoints(data.strikePoints);
        if (data.extraMinutesUnlocked) setExtraMinutesUnlocked(data.extraMinutesUnlocked);
      } catch {}
    });
  }, []);

  const persist = useCallback(
    (patch: Record<string, unknown> = {}) => {
      AsyncStorage.setItem(
        STORAGE_KEY,
        JSON.stringify({
          isFocusModeActive,
          blurEnabled,
          globalLimitMinutes,
          appLimits,
          strikePoints,
          extraMinutesUnlocked,
          ...patch,
        })
      );
    },
    [isFocusModeActive, blurEnabled, globalLimitMinutes, appLimits, strikePoints, extraMinutesUnlocked]
  );

  const toggleFocusMode = useCallback(() => {
    setIsFocusModeActive((prev) => {
      persist({ isFocusModeActive: !prev });
      return !prev;
    });
  }, [persist]);

  const toggleBlur = useCallback(() => {
    setBlurEnabled((prev) => {
      persist({ blurEnabled: !prev });
      return !prev;
    });
  }, [persist]);

  const setGlobalLimit = useCallback(
    (minutes: number) => {
      setGlobalLimitMinutes(minutes);
      persist({ globalLimitMinutes: minutes });
    },
    [persist]
  );

  const setAppLimit = useCallback(
    (appId: string, limitMinutes: number, enabled: boolean) => {
      setAppLimits((prev) => {
        const next = prev.map((a) => (a.appId === appId ? { ...a, limitMinutes, enabled } : a));
        persist({ appLimits: next });
        return next;
      });
    },
    [persist]
  );

  const spendStrikePoints = useCallback(
    (cost: number): boolean => {
      if (strikePoints < cost) return false;
      const next = strikePoints - cost;
      setStrikePoints(next);
      setExtraMinutesUnlocked((prev) => {
        const extra = cost >= 50 ? 60 : cost >= 35 ? 30 : 15;
        persist({ strikePoints: next, extraMinutesUnlocked: prev + extra });
        return prev + extra;
      });
      return true;
    },
    [strikePoints, persist]
  );

  return (
    <FocusContext.Provider
      value={{
        isFocusModeActive,
        blurEnabled,
        globalLimitMinutes,
        appLimits,
        currentStreak,
        strikePoints,
        strikePointsToday,
        strikeStatus,
        extraMinutesUnlocked,
        toggleFocusMode,
        toggleBlur,
        setGlobalLimit,
        setAppLimit,
        spendStrikePoints,
      }}
    >
      {children}
    </FocusContext.Provider>
  );
}

export function useFocus(): FocusContextValue {
  const ctx = useContext(FocusContext);
  if (!ctx) throw new Error("useFocus must be used inside FocusProvider");
  return ctx;
}

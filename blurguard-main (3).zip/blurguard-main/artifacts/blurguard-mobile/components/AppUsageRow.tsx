import React, { useEffect, useRef } from "react";
import { View, Text, StyleSheet, Animated, Easing } from "react-native";
import { Feather } from "@expo/vector-icons";
import { useColors } from "@/hooks/useColors";
import { formatMinutes } from "@/data/mockData";
import type { AppUsage } from "@/data/mockData";
import { AppIconSVG } from "@/components/AppIconSVG";

interface AppUsageRowProps {
  item: AppUsage;
  index: number;
}

export function AppUsageRow({ item, index }: AppUsageRowProps) {
  const colors = useColors();
  const widthAnim = useRef(new Animated.Value(0)).current;
  const isOverLimit = item.usageMinutes > item.limitMinutes;

  useEffect(() => {
    Animated.timing(widthAnim, {
      toValue: item.percentageOfDay / 100,
      duration: 900,
      delay: index * 80,
      easing: Easing.out(Easing.quad),
      useNativeDriver: false,
    }).start();
  }, []);

  return (
    <View style={[styles.row, { borderBottomColor: colors.border }]}>
      <View style={styles.iconWrap}>
        <AppIconSVG appId={item.id} size={42} />
      </View>
      <View style={styles.info}>
        <View style={styles.topRow}>
          <Text style={[styles.appName, { color: colors.foreground, fontFamily: "Poppins_600SemiBold" }]}>
            {item.name}
          </Text>
          <View style={styles.timeRow}>
            {isOverLimit && (
              <Feather name="alert-triangle" size={12} color={colors.warning} style={{ marginRight: 4 }} />
            )}
            <Text style={[styles.timeText, { color: colors.mutedForeground, fontFamily: "Poppins_400Regular" }]}>
              {formatMinutes(item.usageMinutes)}
            </Text>
          </View>
        </View>
        <View style={[styles.trackBg, { backgroundColor: colors.muted }]}>
          <Animated.View
            style={[
              styles.trackFill,
              {
                backgroundColor: isOverLimit ? colors.warning : item.iconColor,
                width: widthAnim.interpolate({
                  inputRange: [0, 1],
                  outputRange: ["0%", `${item.percentageOfDay}%`],
                }),
              },
            ]}
          />
        </View>
      </View>
      <Text style={[styles.percent, { color: colors.mutedForeground, fontFamily: "Poppins_400Regular" }]}>
        {item.percentageOfDay}%
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  row: {
    flexDirection: "row",
    alignItems: "center",
    paddingVertical: 11,
    borderBottomWidth: StyleSheet.hairlineWidth,
    gap: 12,
  },
  iconWrap: {
    borderRadius: 12,
    overflow: "hidden",
  },
  info: {
    flex: 1,
    gap: 6,
  },
  topRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
  appName: { fontSize: 14 },
  timeRow: { flexDirection: "row", alignItems: "center" },
  timeText: { fontSize: 13 },
  trackBg: { height: 5, borderRadius: 3, overflow: "hidden" },
  trackFill: { height: "100%", borderRadius: 3 },
  percent: { fontSize: 12, width: 32, textAlign: "right" },
});

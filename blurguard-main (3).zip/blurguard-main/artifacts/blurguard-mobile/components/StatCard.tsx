import React from "react";
import { View, Text, StyleSheet } from "react-native";
import { Feather } from "@expo/vector-icons";
import { useColors } from "@/hooks/useColors";
import { GlassCard } from "@/components/GlassCard";

interface StatCardProps {
  value: string;
  label: string;
  iconName: keyof typeof Feather.glyphMap;
  iconColor?: string;
}

export function StatCard({ value, label, iconName, iconColor }: StatCardProps) {
  const colors = useColors();
  const resolvedIconColor = iconColor ?? colors.primary;

  return (
    <GlassCard padding={14} borderRadius={16} style={styles.card}>
      <Feather name={iconName} size={18} color={resolvedIconColor} />
      <Text style={[styles.value, { color: colors.foreground, fontFamily: "Poppins_700Bold" }]}>
        {value}
      </Text>
      <Text style={[styles.label, { color: colors.mutedForeground, fontFamily: "Poppins_400Regular" }]}>
        {label}
      </Text>
    </GlassCard>
  );
}

const styles = StyleSheet.create({
  card: {
    flex: 1,
    alignItems: "center",
    gap: 4,
  },
  value: {
    fontSize: 22,
    lineHeight: 28,
    marginTop: 4,
  },
  label: {
    fontSize: 11,
    textAlign: "center",
  },
});

import { LinearGradient } from "expo-linear-gradient";
import React, { useEffect, useRef } from "react";
import {
  Animated,
  Easing,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from "react-native";
import { useColors } from "@/hooks/useColors";
import { formatMinutes } from "@/data/mockData";
import type { BarChartItem } from "@/data/mockData";

const BAR_WIDTH = 44;
const BAR_GAP = 18;

interface BarItemProps {
  item: BarChartItem;
  maxValue: number;
  maxBarHeight: number;
  index: number;
}

function AnimatedBarItem({ item, maxValue, maxBarHeight, index }: BarItemProps) {
  const heightAnim = useRef(new Animated.Value(0)).current;
  const opacityAnim = useRef(new Animated.Value(0)).current;
  const targetHeight = maxValue === 0 ? 0 : (item.value / maxValue) * maxBarHeight;
  const colors = useColors();

  useEffect(() => {
    Animated.parallel([
      Animated.timing(heightAnim, {
        toValue: targetHeight,
        duration: 900,
        delay: index * 80,
        easing: Easing.out(Easing.cubic),
        useNativeDriver: false,
      }),
      Animated.timing(opacityAnim, {
        toValue: 1,
        duration: 400,
        delay: index * 80,
        useNativeDriver: false,
      }),
    ]).start();
  }, [targetHeight]);

  return (
    <Animated.View style={[styles.barColumn, { opacity: opacityAnim }]}>
      <Text style={[styles.valueLabel, { color: "#aaa", fontFamily: "Poppins_400Regular" }]}>
        {formatMinutes(item.value)}
      </Text>
      <View style={[styles.barTrack, { height: maxBarHeight }]}>
        <Animated.View style={[styles.barFill, { height: heightAnim }]}>
          <LinearGradient
            colors={[item.gradientColors[1], item.gradientColors[0]]}
            start={{ x: 0, y: 0 }}
            end={{ x: 0, y: 1 }}
            style={StyleSheet.absoluteFill}
          />
          <View style={[styles.glowTop, { backgroundColor: item.gradientColors[1] + "60" }]} />
        </Animated.View>
      </View>
      <Text style={[styles.shortLabel, { color: "#888", fontFamily: "Poppins_400Regular" }]}>
        {item.shortLabel}
      </Text>
    </Animated.View>
  );
}

interface BarChartProps {
  data: BarChartItem[];
  maxBarHeight?: number;
}

export function BarChart({ data, maxBarHeight = 150 }: BarChartProps) {
  const maxValue = Math.max(...data.map((d) => d.value), 1);

  return (
    <ScrollView
      horizontal
      showsHorizontalScrollIndicator={false}
      contentContainerStyle={[styles.container, { paddingBottom: 4 }]}
    >
      {data.map((item, i) => (
        <AnimatedBarItem
          key={item.label}
          item={item}
          maxValue={maxValue}
          maxBarHeight={maxBarHeight}
          index={i}
        />
      ))}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection: "row",
    alignItems: "flex-end",
    gap: BAR_GAP,
    paddingHorizontal: 4,
    paddingTop: 8,
  },
  barColumn: {
    alignItems: "center",
    width: BAR_WIDTH,
    gap: 6,
  },
  valueLabel: {
    fontSize: 10,
    textAlign: "center",
  },
  barTrack: {
    justifyContent: "flex-end",
    width: BAR_WIDTH,
  },
  barFill: {
    width: BAR_WIDTH,
    borderRadius: 10,
    overflow: "hidden",
    position: "relative",
  },
  glowTop: {
    position: "absolute",
    top: 0,
    left: 0,
    right: 0,
    height: 12,
    borderTopLeftRadius: 10,
    borderTopRightRadius: 10,
  },
  shortLabel: {
    fontSize: 11,
    textAlign: "center",
  },
});

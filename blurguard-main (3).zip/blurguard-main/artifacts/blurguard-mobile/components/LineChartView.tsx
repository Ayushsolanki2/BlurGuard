import React from "react";
import { View, Text, StyleSheet } from "react-native";
import Svg, { Polyline, Circle as SvgCircle, Line, Defs, LinearGradient, Stop, Polygon } from "react-native-svg";
import { useColors } from "@/hooks/useColors";

interface LineChartViewProps {
  data: number[];
  limitData: number[];
  labels: string[];
  maxValue?: number;
  width?: number;
  height?: number;
}

export function LineChartView({ data, limitData, labels, maxValue = 10, width = 320, height = 150 }: LineChartViewProps) {
  const colors = useColors();
  const padLeft = 28;
  const padRight = 12;
  const padTop = 12;
  const padBottom = 24;
  const chartW = width - padLeft - padRight;
  const chartH = height - padTop - padBottom;

  const toX = (i: number) => padLeft + (i / (data.length - 1)) * chartW;
  const toY = (v: number) => padTop + (1 - v / maxValue) * chartH;

  const usagePoints = data.map((v, i) => `${toX(i)},${toY(v)}`).join(" ");
  const limitPoints = limitData.map((v, i) => `${toX(i)},${toY(v)}`).join(" ");
  const fillPoints = [
    ...data.map((v, i) => `${toX(i)},${toY(v)}`),
    `${toX(data.length - 1)},${padTop + chartH}`,
    `${toX(0)},${padTop + chartH}`,
  ].join(" ");

  const yTicks = [0, 2, 4, 6, 8, 10];

  return (
    <View style={styles.wrapper}>
      <Svg width={width} height={height}>
        <Defs>
          <LinearGradient id="fillGrad" x1="0" y1="0" x2="0" y2="1">
            <Stop offset="0%" stopColor={colors.primary} stopOpacity={0.35} />
            <Stop offset="100%" stopColor={colors.primary} stopOpacity={0.0} />
          </LinearGradient>
        </Defs>
        {yTicks.map((tick) => (
          <React.Fragment key={tick}>
            <Line
              x1={padLeft}
              y1={toY(tick)}
              x2={padLeft + chartW}
              y2={toY(tick)}
              stroke={colors.border}
              strokeWidth={0.5}
              strokeDasharray="3,3"
            />
            <Text
              style={[styles.yLabel, { color: colors.mutedForeground, top: toY(tick) - 8, left: 0 }]}
            >
              {tick}h
            </Text>
          </React.Fragment>
        ))}
        <Polygon points={fillPoints} fill="url(#fillGrad)" />
        <Polyline
          points={limitPoints}
          fill="none"
          stroke={colors.secondary}
          strokeWidth={2}
          strokeDasharray="6,4"
        />
        <Polyline points={usagePoints} fill="none" stroke={colors.primary} strokeWidth={2.5} />
        {data.map((v, i) => (
          <SvgCircle
            key={i}
            cx={toX(i)}
            cy={toY(v)}
            r={4}
            fill={colors.primary}
            stroke={colors.background}
            strokeWidth={2}
          />
        ))}
      </Svg>
      <View style={[styles.labelsRow, { paddingLeft: padLeft, paddingRight: padRight }]}>
        {labels.map((label, i) => (
          <Text key={i} style={[styles.xLabel, { color: colors.mutedForeground }]}>
            {label}
          </Text>
        ))}
      </View>
      <View style={styles.legend}>
        <View style={styles.legendItem}>
          <View style={[styles.legendDot, { backgroundColor: colors.primary }]} />
          <Text style={[styles.legendText, { color: colors.mutedForeground }]}>Usage</Text>
        </View>
        <View style={styles.legendItem}>
          <View style={[styles.legendDash, { backgroundColor: colors.secondary }]} />
          <Text style={[styles.legendText, { color: colors.mutedForeground }]}>Goal</Text>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  wrapper: {
    position: "relative",
  },
  yLabel: {
    position: "absolute",
    fontSize: 9,
    fontFamily: "Poppins_400Regular",
  },
  labelsRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginTop: -8,
  },
  xLabel: {
    fontSize: 9,
    fontFamily: "Poppins_400Regular",
    textAlign: "center",
  },
  legend: {
    flexDirection: "row",
    gap: 16,
    marginTop: 8,
    paddingLeft: 28,
  },
  legendItem: {
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
  },
  legendDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
  },
  legendDash: {
    width: 16,
    height: 2,
    borderRadius: 1,
  },
  legendText: {
    fontSize: 11,
    fontFamily: "Poppins_400Regular",
  },
});

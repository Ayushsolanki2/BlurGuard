import React, { useState } from "react";
import { View, Text, StyleSheet, Pressable } from "react-native";
import Svg, { Path, G } from "react-native-svg";
import { useColors } from "@/hooks/useColors";
import type { donutData } from "@/data/mockData";

interface DonutChartViewProps {
  data: typeof donutData;
  size?: number;
}

function polarToCartesian(cx: number, cy: number, r: number, angleDeg: number) {
  const angle = ((angleDeg - 90) * Math.PI) / 180;
  return {
    x: cx + r * Math.cos(angle),
    y: cy + r * Math.sin(angle),
  };
}

function arcPath(cx: number, cy: number, r: number, startAngle: number, endAngle: number) {
  const start = polarToCartesian(cx, cy, r, endAngle);
  const end = polarToCartesian(cx, cy, r, startAngle);
  const largeArcFlag = endAngle - startAngle <= 180 ? 0 : 1;
  return `M ${start.x} ${start.y} A ${r} ${r} 0 ${largeArcFlag} 0 ${end.x} ${end.y}`;
}

export function DonutChartView({ data, size = 200 }: DonutChartViewProps) {
  const colors = useColors();
  const [selected, setSelected] = useState<number | null>(null);
  const cx = size / 2;
  const cy = size / 2;
  const outerR = size / 2 - 12;
  const innerR = outerR * 0.55;
  const expandedOuter = outerR + 10;

  let currentAngle = 0;
  const slices = data.map((d, i) => {
    const startAngle = currentAngle;
    const sweep = (d.percentage / 100) * 360;
    currentAngle += sweep;
    return { ...d, startAngle, endAngle: currentAngle, index: i };
  });

  const selectedItem = selected !== null ? data[selected] : null;

  return (
    <View style={styles.wrapper}>
      <View style={styles.svgWrap}>
        <Svg width={size} height={size}>
          <G>
            {slices.map((slice, i) => {
              const isSelected = selected === i;
              const r = isSelected ? expandedOuter : outerR;
              const path = arcPath(cx, cy, r, slice.startAngle, slice.endAngle);
              const innerPath = arcPath(cx, cy, innerR, slice.endAngle, slice.startAngle);
              const fullPath = `${path} L ${polarToCartesian(cx, cy, innerR, slice.endAngle).x} ${polarToCartesian(cx, cy, innerR, slice.endAngle).y} ${innerPath} Z`;
              return (
                <Path
                  key={i}
                  d={fullPath}
                  fill={slice.color}
                  opacity={selected !== null && !isSelected ? 0.5 : 1}
                  onPress={() => setSelected(selected === i ? null : i)}
                />
              );
            })}
          </G>
        </Svg>
        <View style={styles.centerLabel}>
          {selectedItem ? (
            <>
              <Text style={[styles.centerBig, { color: selectedItem.color, fontFamily: "Poppins_700Bold" }]}>
                {selectedItem.percentage}%
              </Text>
              <Text style={[styles.centerSub, { color: colors.mutedForeground, fontFamily: "Poppins_400Regular" }]}>
                {selectedItem.name}
              </Text>
            </>
          ) : (
            <>
              <Text style={[styles.centerBig, { color: colors.foreground, fontFamily: "Poppins_700Bold" }]}>
                {data.length}
              </Text>
              <Text style={[styles.centerSub, { color: colors.mutedForeground, fontFamily: "Poppins_400Regular" }]}>
                Apps
              </Text>
            </>
          )}
        </View>
      </View>
      <View style={styles.legend}>
        {data.map((d, i) => (
          <Pressable key={i} onPress={() => setSelected(selected === i ? null : i)} style={styles.legendItem}>
            <View style={[styles.legendDot, { backgroundColor: d.color }]} />
            <Text style={[styles.legendText, { color: colors.foreground, fontFamily: "Poppins_400Regular" }]}>
              {d.name}
            </Text>
            <Text style={[styles.legendPct, { color: colors.mutedForeground, fontFamily: "Poppins_400Regular" }]}>
              {d.percentage}%
            </Text>
          </Pressable>
        ))}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  wrapper: {
    alignItems: "center",
    gap: 16,
  },
  svgWrap: {
    alignItems: "center",
    justifyContent: "center",
  },
  centerLabel: {
    position: "absolute",
    alignItems: "center",
    justifyContent: "center",
  },
  centerBig: {
    fontSize: 28,
    lineHeight: 34,
  },
  centerSub: {
    fontSize: 11,
  },
  legend: {
    width: "100%",
    gap: 8,
  },
  legendItem: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
  },
  legendDot: {
    width: 10,
    height: 10,
    borderRadius: 5,
  },
  legendText: {
    flex: 1,
    fontSize: 13,
  },
  legendPct: {
    fontSize: 13,
  },
});

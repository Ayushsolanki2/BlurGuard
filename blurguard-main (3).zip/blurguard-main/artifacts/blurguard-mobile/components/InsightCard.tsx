import React from "react";
import { View, Text, StyleSheet, Pressable } from "react-native";
import { Feather } from "@expo/vector-icons";
import { useColors } from "@/hooks/useColors";
import type { InsightItem } from "@/data/mockData";

interface InsightCardProps {
  item: InsightItem;
}

export function InsightCard({ item }: InsightCardProps) {
  const colors = useColors();

  return (
    <Pressable style={({ pressed }) => [{ opacity: pressed ? 0.85 : 1 }]}>
      <View
        style={[
          styles.card,
          {
            backgroundColor: colors.card,
            borderColor: colors.border,
            borderLeftColor: item.accentColor,
          },
        ]}
      >
        <View style={[styles.iconWrap, { backgroundColor: item.accentColor + "22" }]}>
          <Feather name={item.iconName as keyof typeof Feather.glyphMap} size={18} color={item.accentColor} />
        </View>
        <Text style={[styles.title, { color: colors.foreground, fontFamily: "Poppins_600SemiBold" }]}>
          {item.title}
        </Text>
        <Text style={[styles.desc, { color: colors.mutedForeground, fontFamily: "Poppins_400Regular" }]}>
          {item.description}
        </Text>
      </View>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  card: {
    width: 200,
    borderRadius: 16,
    borderWidth: 1,
    borderLeftWidth: 3,
    padding: 14,
    gap: 8,
  },
  iconWrap: {
    width: 36,
    height: 36,
    borderRadius: 10,
    alignItems: "center",
    justifyContent: "center",
  },
  title: {
    fontSize: 14,
    lineHeight: 20,
  },
  desc: {
    fontSize: 12,
    lineHeight: 18,
  },
});

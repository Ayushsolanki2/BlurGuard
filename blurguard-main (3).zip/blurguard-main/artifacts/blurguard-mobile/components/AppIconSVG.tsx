import React from "react";
import Svg, {
  Circle,
  Defs,
  Ellipse,
  LinearGradient,
  Path,
  Polygon,
  Rect,
  Stop,
  Line,
  G,
} from "react-native-svg";

interface AppIconProps {
  appId: string;
  size?: number;
}

export function AppIconSVG({ appId, size = 40 }: AppIconProps) {
  switch (appId) {
    case "1": return <InstagramIcon size={size} />;
    case "2": return <YouTubeIcon size={size} />;
    case "3": return <WhatsAppIcon size={size} />;
    case "4": return <ChromeIcon size={size} />;
    case "5": return <SpotifyIcon size={size} />;
    case "6": return <GmailIcon size={size} />;
    default: return null;
  }
}

function InstagramIcon({ size }: { size: number }) {
  const s = size / 2;
  return (
    <Svg width={size} height={size} viewBox="0 0 40 40">
      <Defs>
        <LinearGradient id="ig1" x1="0" y1="1" x2="1" y2="0">
          <Stop offset="0" stopColor="#f09433" />
          <Stop offset="0.25" stopColor="#e6683c" />
          <Stop offset="0.5" stopColor="#dc2743" />
          <Stop offset="0.75" stopColor="#cc2366" />
          <Stop offset="1" stopColor="#bc1888" />
        </LinearGradient>
      </Defs>
      <Rect x="1" y="1" width="38" height="38" rx="10" fill="url(#ig1)" />
      <Rect x="9" y="11" width="22" height="18" rx="5" stroke="white" strokeWidth="2" fill="none" />
      <Circle cx="20" cy="20" r="6" stroke="white" strokeWidth="2" fill="none" />
      <Circle cx="20" cy="20" r="2.5" fill="white" opacity="0.3" />
      <Circle cx="28.5" cy="12.5" r="2" fill="white" />
    </Svg>
  );
}

function YouTubeIcon({ size }: { size: number }) {
  return (
    <Svg width={size} height={size} viewBox="0 0 40 40">
      <Rect x="1" y="7" width="38" height="26" rx="8" fill="#FF0000" />
      <Polygon points="16,14 16,26 28,20" fill="white" />
    </Svg>
  );
}

function WhatsAppIcon({ size }: { size: number }) {
  return (
    <Svg width={size} height={size} viewBox="0 0 40 40">
      <Circle cx="20" cy="20" r="19" fill="#25D366" />
      <Path
        d="M20 8 C13.4 8 8 13.4 8 20 C8 22.4 8.7 24.6 9.9 26.5 L8 32 L13.8 30.2 C15.6 31.3 17.7 32 20 32 C26.6 32 32 26.6 32 20 C32 13.4 26.6 8 20 8 Z"
        fill="white"
        opacity="0.15"
      />
      <Path
        d="M15 15.5 C15.4 14.8 16 14.5 16.6 14.5 C16.9 14.5 17.1 14.5 17.3 14.5 C17.6 14.5 18 14.6 18.4 15.7 L19.3 18.1 C19.5 18.6 19.4 19 19.1 19.4 L18.5 20 C18.3 20.2 18.3 20.4 18.4 20.6 C18.9 21.5 19.7 22.4 20.6 23.1 C21.3 23.6 22 24 22.5 24.2 C22.8 24.3 23 24.3 23.2 24.1 L23.9 23.3 C24.2 22.9 24.6 22.8 25.1 23 L27.5 24.1 C28.1 24.4 28.3 24.7 28.2 25.2 C28 26 27.3 27 26.4 27.3 C24.1 27.9 20.2 27 17.3 24 C15.5 22.2 14.5 19.8 14.5 18.1 C14.5 17 14.7 16.2 15 15.5 Z"
        fill="white"
      />
    </Svg>
  );
}

function ChromeIcon({ size }: { size: number }) {
  // Three 120° segments meeting at center, then white overlay, then blue circle
  // Center: 20,20 | Outer radius: 17
  // Angles: Red 270°→30°, Yellow 30°→150°, Green 150°→270°
  // (20,3) → (34.7,28.5) → (5.3,28.5) → (20,3)
  return (
    <Svg width={size} height={size} viewBox="0 0 40 40">
      {/* Background */}
      <Circle cx="20" cy="20" r="19" fill="#F1F1F1" />
      {/* Red segment */}
      <Path d="M20,20 L20,3 A17,17 0 0,1 34.7,28.5 Z" fill="#EA4335" />
      {/* Yellow segment */}
      <Path d="M20,20 L34.7,28.5 A17,17 0 0,1 5.3,28.5 Z" fill="#FBBC04" />
      {/* Green segment */}
      <Path d="M20,20 L5.3,28.5 A17,17 0 0,1 20,3 Z" fill="#34A853" />
      {/* White separator ring */}
      <Circle cx="20" cy="20" r="10" fill="white" />
      {/* Blue inner circle */}
      <Circle cx="20" cy="20" r="8.5" fill="#4285F4" />
      {/* Small white center highlight */}
      <Circle cx="18" cy="18" r="2.5" fill="white" opacity="0.4" />
    </Svg>
  );
}

function SpotifyIcon({ size }: { size: number }) {
  return (
    <Svg width={size} height={size} viewBox="0 0 40 40">
      <Circle cx="20" cy="20" r="19" fill="#1DB954" />
      {/* 3 white wave arcs */}
      <Path d="M10,15 Q20,10 30,15" stroke="white" strokeWidth="2.5" fill="none" strokeLinecap="round" />
      <Path d="M11.5,21 Q20,16 28.5,21" stroke="white" strokeWidth="2.5" fill="none" strokeLinecap="round" />
      <Path d="M13,27 Q20,22.5 27,27" stroke="white" strokeWidth="2.5" fill="none" strokeLinecap="round" />
    </Svg>
  );
}

function GmailIcon({ size }: { size: number }) {
  return (
    <Svg width={size} height={size} viewBox="0 0 40 40">
      <Rect x="1" y="1" width="38" height="38" rx="8" fill="white" />
      {/* Envelope body */}
      <Rect x="5" y="11" width="30" height="22" rx="2" fill="#F1F1F1" stroke="#E0E0E0" strokeWidth="0.5" />
      {/* Red M shape (left flap, right flap, middle) */}
      <Path d="M5,11 L20,23 L35,11 Z" fill="#EA4335" />
      <Rect x="5" y="11" width="5" height="22" rx="0" fill="#C62828" />
      <Rect x="30" y="11" width="5" height="22" rx="0" fill="#C62828" />
      <Path d="M5,11 L20,23 L35,11" stroke="white" strokeWidth="1" fill="none" />
    </Svg>
  );
}

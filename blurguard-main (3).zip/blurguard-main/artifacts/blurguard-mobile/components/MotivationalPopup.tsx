import { LinearGradient } from "expo-linear-gradient";
import React, { useEffect, useRef, useState } from "react";
import {
  Animated,
  Easing,
  Modal,
  Platform,
  StyleSheet,
  Text,
  View,
} from "react-native";
import Svg, {
  Circle,
  Defs,
  Ellipse,
  Line,
  Path,
  RadialGradient,
  Rect,
  Stop,
  Text as SvgText,
} from "react-native-svg";

export type PopupType = "happy" | "caution" | "tired" | "blocked";

interface PopupConfig {
  headline: string;
  body: string;
  gradientColors: [string, string];
  accentColor: string;
  bgColor: string;
  borderColor: string;
}

const CONFIGS: Record<PopupType, PopupConfig> = {
  happy: {
    headline: "Nice going",
    body: "Take small breaks to stay fresh and focused.",
    gradientColors: ["#00D4AA", "#3B82F6"],
    accentColor: "#00D4AA",
    bgColor: "#0A1F18",
    borderColor: "#00D4AA40",
  },
  caution: {
    headline: "Almost there",
    body: "Blur Mode starts in 20 minutes.",
    gradientColors: ["#F59E0B", "#EF4444"],
    accentColor: "#F59E0B",
    bgColor: "#1F1500",
    borderColor: "#F59E0B40",
  },
  tired: {
    headline: "Eyes need rest",
    body: "Screen blur is starting now.",
    gradientColors: ["#EF4444", "#8B5CF6"],
    accentColor: "#EF4444",
    bgColor: "#1F0808",
    borderColor: "#EF444440",
  },
  blocked: {
    headline: "Time's up",
    body: "Blocked apps will unlock tomorrow.",
    gradientColors: ["#8B5CF6", "#6366F1"],
    accentColor: "#8B5CF6",
    bgColor: "#100818",
    borderColor: "#8B5CF640",
  },
};

// ─── Mascot Characters ────────────────────────────────────────────────────────

function HappyMascot({ isBlinking }: { isBlinking: boolean }) {
  return (
    <Svg width="90" height="90" viewBox="0 0 100 100">
      <Defs>
        <RadialGradient id="hbody" cx="40%" cy="38%" r="60%">
          <Stop offset="0" stopColor="#00E8BE" />
          <Stop offset="1" stopColor="#00957A" />
        </RadialGradient>
      </Defs>
      {/* Body */}
      <Circle cx="50" cy="58" r="36" fill="url(#hbody)" />
      {/* Shine */}
      <Ellipse cx="38" cy="44" rx="10" ry="7" fill="white" opacity="0.2" />
      {/* Left eye white */}
      <Ellipse cx="37" cy="52" rx="8" ry={isBlinking ? 1 : 9} fill="white" />
      <Circle cx="39" cy="54" r="4.5" fill="#0A2A1F" />
      <Circle cx="41" cy="51" r="1.8" fill="white" />
      {/* Right eye white */}
      <Ellipse cx="63" cy="52" rx="8" ry={isBlinking ? 1 : 9} fill="white" />
      <Circle cx="65" cy="54" r="4.5" fill="#0A2A1F" />
      <Circle cx="67" cy="51" r="1.8" fill="white" />
      {/* Blush */}
      <Ellipse cx="26" cy="62" rx="7" ry="5" fill="#FF9999" opacity="0.55" />
      <Ellipse cx="74" cy="62" rx="7" ry="5" fill="#FF9999" opacity="0.55" />
      {/* Big smile */}
      <Path d="M33,68 Q50,82 67,68" stroke="white" strokeWidth="3" fill="none" strokeLinecap="round" />
      {/* Tongue */}
      <Ellipse cx="50" cy="75" rx="7" ry="4.5" fill="#FF6688" />
      {/* Leaf on head */}
      <Path d="M50,22 Q42,10 34,14 Q40,11 38,19 Q43,15 50,22" fill="#00D4AA" />
      <Path d="M50,22 Q58,10 66,14 Q60,11 62,19 Q57,15 50,22" fill="#00B38A" />
      {/* Stem */}
      <Line x1="50" y1="22" x2="50" y2="26" stroke="#00B38A" strokeWidth="2" strokeLinecap="round" />
      {/* Star sparkles */}
      <Path d="M18,28 L19.5,25 L21,28 L24,29.5 L21,31 L19.5,34 L18,31 L15,29.5 Z" fill="#FFD700" opacity="0.8" />
      <Path d="M80,22 L81,19.5 L82,22 L84.5,23 L82,24 L81,26.5 L80,24 L77.5,23 Z" fill="#FFD700" opacity="0.7" />
    </Svg>
  );
}

function CautionMascot({ isBlinking }: { isBlinking: boolean }) {
  return (
    <Svg width="90" height="90" viewBox="0 0 100 100">
      <Defs>
        <RadialGradient id="cbody" cx="40%" cy="38%" r="60%">
          <Stop offset="0" stopColor="#FBBF24" />
          <Stop offset="1" stopColor="#D97706" />
        </RadialGradient>
      </Defs>
      {/* Body */}
      <Circle cx="50" cy="58" r="36" fill="url(#cbody)" />
      <Ellipse cx="38" cy="44" rx="10" ry="7" fill="white" opacity="0.2" />
      {/* Eyebrows (worried: inner corners raised) */}
      <Path d="M27,39 Q34,34 41,38" stroke="#92400E" strokeWidth="3" fill="none" strokeLinecap="round" />
      <Path d="M59,38 Q66,34 73,39" stroke="#92400E" strokeWidth="3" fill="none" strokeLinecap="round" />
      {/* Left eye */}
      <Ellipse cx="37" cy="51" rx="8" ry={isBlinking ? 1 : 9} fill="white" />
      <Circle cx="39" cy="53" r="4.5" fill="#2A1500" />
      <Circle cx="41" cy="50" r="1.8" fill="white" />
      {/* Right eye */}
      <Ellipse cx="63" cy="51" rx="8" ry={isBlinking ? 1 : 9} fill="white" />
      <Circle cx="65" cy="53" r="4.5" fill="#2A1500" />
      <Circle cx="67" cy="50" r="1.8" fill="white" />
      {/* Frown */}
      <Path d="M35,70 Q50,62 65,70" stroke="white" strokeWidth="3" fill="none" strokeLinecap="round" />
      {/* Sweat drop */}
      <Path d="M78,34 Q81,28 84,34 Q84,39 78,39 Z" fill="#60C0FF" />
      {/* Clock on forehead */}
      <Circle cx="50" cy="38" r="6" fill="white" opacity="0.9" />
      <Line x1="50" y1="34" x2="50" y2="38" stroke="#92400E" strokeWidth="1.5" strokeLinecap="round" />
      <Line x1="50" y1="38" x2="54" y2="38" stroke="#92400E" strokeWidth="1.5" strokeLinecap="round" />
    </Svg>
  );
}

function TiredMascot({ isBlinking }: { isBlinking: boolean }) {
  return (
    <Svg width="90" height="90" viewBox="0 0 100 100">
      <Defs>
        <RadialGradient id="tbody" cx="40%" cy="38%" r="60%">
          <Stop offset="0" stopColor="#F87171" />
          <Stop offset="1" stopColor="#B91C1C" />
        </RadialGradient>
      </Defs>
      {/* Body */}
      <Circle cx="50" cy="58" r="36" fill="url(#tbody)" />
      <Ellipse cx="38" cy="44" rx="10" ry="7" fill="white" opacity="0.15" />
      {/* Droopy left eye */}
      <Ellipse cx="37" cy="54" rx="8" ry={isBlinking ? 1 : 8} fill="white" />
      <Circle cx="38" cy="57" r="4" fill="#2A0808" />
      <Circle cx="40" cy="54" r="1.5" fill="white" />
      {/* Heavy eyelid left (covers top ~55%) */}
      <Path d="M27,54 Q37,46 47,54" fill="#B91C1C" />
      {/* Droopy right eye */}
      <Ellipse cx="63" cy="54" rx="8" ry={isBlinking ? 1 : 8} fill="white" />
      <Circle cx="64" cy="57" r="4" fill="#2A0808" />
      <Circle cx="66" cy="54" r="1.5" fill="white" />
      {/* Heavy eyelid right */}
      <Path d="M53,54 Q63,46 73,54" fill="#B91C1C" />
      {/* Blush (extra tired blush) */}
      <Ellipse cx="24" cy="62" rx="7" ry="5" fill="#FF6666" opacity="0.45" />
      <Ellipse cx="76" cy="62" rx="7" ry="5" fill="#FF6666" opacity="0.45" />
      {/* Wavy exhausted mouth */}
      <Path d="M35,70 Q41,67 46,71 Q51,75 56,71 Q61,67 65,70" stroke="white" strokeWidth="2.5" fill="none" strokeLinecap="round" />
      {/* ZZZ */}
      <SvgText x="72" y="38" fontSize="10" fontWeight="bold" fill="white" opacity="0.9">Z</SvgText>
      <SvgText x="80" y="28" fontSize="13" fontWeight="bold" fill="white" opacity="0.7">Z</SvgText>
      <SvgText x="70" y="20" fontSize="8" fontWeight="bold" fill="white" opacity="0.5">z</SvgText>
    </Svg>
  );
}

function BlockedMascot({ isBlinking }: { isBlinking: boolean }) {
  return (
    <Svg width="90" height="90" viewBox="0 0 100 100">
      <Defs>
        <RadialGradient id="bbody" cx="40%" cy="38%" r="60%">
          <Stop offset="0" stopColor="#7C3AED" />
          <Stop offset="1" stopColor="#4C1D95" />
        </RadialGradient>
      </Defs>
      {/* Body */}
      <Circle cx="50" cy="58" r="36" fill="url(#bbody)" />
      <Ellipse cx="38" cy="44" rx="10" ry="7" fill="white" opacity="0.1" />
      {/* X left eye */}
      <Line x1="28" y1="44" x2="40" y2="56" stroke="white" strokeWidth="3.5" strokeLinecap="round" />
      <Line x1="40" y1="44" x2="28" y2="56" stroke="white" strokeWidth="3.5" strokeLinecap="round" />
      {/* X right eye */}
      <Line x1="60" y1="44" x2="72" y2="56" stroke="white" strokeWidth="3.5" strokeLinecap="round" />
      <Line x1="72" y1="44" x2="60" y2="56" stroke="white" strokeWidth="3.5" strokeLinecap="round" />
      {/* Flat mouth */}
      <Line x1="36" y1="70" x2="64" y2="70" stroke="white" strokeWidth="3" strokeLinecap="round" opacity="0.8" />
      {/* Lock on forehead */}
      <Rect x="44" y="23" width="12" height="10" rx="2" fill="white" opacity="0.9" />
      <Path d="M46,23 Q46,17 50,17 Q54,17 54,23" stroke="white" strokeWidth="2.5" fill="none" strokeLinecap="round" />
      <Circle cx="50" cy="28" r="2" fill="#4C1D95" />
      {/* Small stars (knocked out) */}
      <Path d="M15,42 L16,39 L17,42 L20,43 L17,44 L16,47 L15,44 L12,43 Z" fill="#FFD700" opacity="0.7" />
      <Path d="M83,38 L84,35.5 L85,38 L87.5,39 L85,40 L84,42.5 L83,40 L80.5,39 Z" fill="#FFD700" opacity="0.6" />
    </Svg>
  );
}

// ─── Main Popup Component ─────────────────────────────────────────────────────

interface MotivationalPopupProps {
  visible: boolean;
  type: PopupType;
  onDismiss: () => void;
}

export function MotivationalPopup({ visible, type, onDismiss }: MotivationalPopupProps) {
  const config = CONFIGS[type];

  const slideAnim = useRef(new Animated.Value(120)).current;
  const fadeAnim = useRef(new Animated.Value(0)).current;
  const scaleAnim = useRef(new Animated.Value(0.7)).current;
  const floatAnim = useRef(new Animated.Value(0)).current;
  const glowAnim = useRef(new Animated.Value(0.4)).current;
  const progressAnim = useRef(new Animated.Value(1)).current;

  const [isBlinking, setIsBlinking] = useState(false);
  const [showing, setShowing] = useState(false);

  useEffect(() => {
    if (visible) {
      setShowing(true);
      progressAnim.setValue(1);

      // Entry animation
      Animated.parallel([
        Animated.spring(slideAnim, { toValue: 0, useNativeDriver: true, tension: 60, friction: 10 }),
        Animated.timing(fadeAnim, { toValue: 1, duration: 300, useNativeDriver: true }),
        Animated.spring(scaleAnim, { toValue: 1, useNativeDriver: true, tension: 80, friction: 8 }),
      ]).start();

      // Float loop
      Animated.loop(
        Animated.sequence([
          Animated.timing(floatAnim, { toValue: -9, duration: 900, easing: Easing.inOut(Easing.sin), useNativeDriver: true }),
          Animated.timing(floatAnim, { toValue: 9, duration: 900, easing: Easing.inOut(Easing.sin), useNativeDriver: true }),
        ])
      ).start();

      // Glow pulse
      Animated.loop(
        Animated.sequence([
          Animated.timing(glowAnim, { toValue: 1, duration: 1000, useNativeDriver: false }),
          Animated.timing(glowAnim, { toValue: 0.35, duration: 1000, useNativeDriver: false }),
        ])
      ).start();

      // Progress bar draining over 3s
      Animated.timing(progressAnim, { toValue: 0, duration: 3000, easing: Easing.linear, useNativeDriver: false }).start();

      // Auto-dismiss after 3s
      const dismissTimer = setTimeout(() => {
        Animated.parallel([
          Animated.timing(slideAnim, { toValue: 120, duration: 320, useNativeDriver: true }),
          Animated.timing(fadeAnim, { toValue: 0, duration: 320, useNativeDriver: true }),
        ]).start(() => {
          setShowing(false);
          floatAnim.stopAnimation();
          glowAnim.stopAnimation();
          onDismiss();
        });
      }, 3000);

      // Blink cycle
      let blinkTimer: ReturnType<typeof setTimeout>;
      const scheduleBlink = () => {
        blinkTimer = setTimeout(() => {
          setIsBlinking(true);
          setTimeout(() => {
            setIsBlinking(false);
            scheduleBlink();
          }, 140);
        }, 2400 + Math.random() * 1200);
      };
      scheduleBlink();

      return () => {
        clearTimeout(dismissTimer);
        clearTimeout(blinkTimer);
        floatAnim.stopAnimation();
        glowAnim.stopAnimation();
      };
    }
  }, [visible]);

  if (!visible && !showing) return null;

  const progressWidth = progressAnim.interpolate({ inputRange: [0, 1], outputRange: ["0%", "100%"] });

  const MascotComp =
    type === "happy" ? HappyMascot :
    type === "caution" ? CautionMascot :
    type === "tired" ? TiredMascot :
    BlockedMascot;

  return (
    <Modal visible={visible || showing} transparent animationType="none" statusBarTranslucent>
      <View style={styles.overlay} pointerEvents="none">
        <Animated.View
          style={[
            styles.card,
            {
              backgroundColor: config.bgColor,
              borderColor: config.borderColor,
              opacity: fadeAnim,
              transform: [{ translateY: slideAnim }, { scale: scaleAnim }],
            },
          ]}
        >
          {/* Glow ring behind card */}
          <Animated.View
            style={[
              styles.glowRing,
              { shadowColor: config.accentColor, shadowOpacity: glowAnim },
            ]}
          />

          <View style={styles.cardInner}>
            {/* Animated mascot */}
            <Animated.View style={[styles.mascotWrap, { transform: [{ translateY: floatAnim }] }]}>
              <MascotComp isBlinking={isBlinking} />
            </Animated.View>

            {/* Text */}
            <View style={styles.textBlock}>
              <LinearGradient
                colors={config.gradientColors}
                start={{ x: 0, y: 0 }}
                end={{ x: 1, y: 0 }}
                style={styles.headlineGrad}
              >
                <Text style={[styles.headline, { fontFamily: "Poppins_700Bold" }]}>{config.headline}</Text>
              </LinearGradient>
              <Text style={[styles.body, { color: "#CCCCDD", fontFamily: "Poppins_400Regular" }]}>{config.body}</Text>
            </View>
          </View>

          {/* Progress countdown bar */}
          <View style={[styles.progressTrack, { backgroundColor: config.accentColor + "30" }]}>
            <Animated.View
              style={[styles.progressFill, { backgroundColor: config.accentColor, width: progressWidth }]}
            />
          </View>
        </Animated.View>
      </View>
    </Modal>
  );
}

export function getPopupTypeForPercentage(pct: number): PopupType {
  if (pct >= 100) return "blocked";
  if (pct >= 95) return "tired";
  if (pct >= 75) return "caution";
  return "happy";
}

const styles = StyleSheet.create({
  overlay: {
    flex: 1,
    justifyContent: "flex-end",
    paddingBottom: Platform.OS === "ios" ? 100 : 90,
    paddingHorizontal: 16,
  },
  glowRing: {
    ...StyleSheet.absoluteFillObject,
    borderRadius: 24,
    shadowOffset: { width: 0, height: 0 },
    shadowRadius: 28,
    elevation: 0,
  },
  card: {
    borderRadius: 24,
    borderWidth: 1,
    overflow: "hidden",
    shadowOffset: { width: 0, height: 8 },
    shadowRadius: 24,
    shadowOpacity: 0.5,
    elevation: 20,
  },
  cardInner: {
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 16,
    paddingTop: 16,
    paddingBottom: 14,
    gap: 12,
  },
  mascotWrap: {
    width: 90,
    height: 90,
  },
  textBlock: {
    flex: 1,
    gap: 5,
  },
  headlineGrad: {
    alignSelf: "flex-start",
    borderRadius: 8,
    paddingHorizontal: 2,
    paddingVertical: 1,
  },
  headline: {
    fontSize: 20,
    color: "#fff",
    lineHeight: 26,
  },
  body: {
    fontSize: 13,
    lineHeight: 19,
  },
  progressTrack: {
    height: 3,
    marginHorizontal: 0,
  },
  progressFill: {
    height: "100%",
    borderRadius: 2,
  },
});

import { LinearGradient } from "expo-linear-gradient";
import React, { useState } from "react";
import {
  Animated,
  Modal,
  Pressable,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from "react-native";
import { Feather } from "@expo/vector-icons";
import { useColors } from "@/hooks/useColors";

interface SpendOption {
  id: string;
  minutes: number;
  cost: number;
  label: string;
  gradientColors: [string, string];
}

const OPTIONS: SpendOption[] = [
  { id: "o1", minutes: 15, cost: 20, label: "15 minutes extra", gradientColors: ["#8B5CF6", "#6366F1"] },
  { id: "o2", minutes: 30, cost: 35, label: "30 minutes extra", gradientColors: ["#3B82F6", "#8B5CF6"] },
  { id: "o3", minutes: 60, cost: 50, label: "1 hour extra", gradientColors: ["#00B38A", "#3B82F6"] },
];

interface SpendPointsModalProps {
  visible: boolean;
  currentPoints: number;
  onClose: () => void;
  onSpend: (cost: number) => boolean;
}

export function SpendPointsModal({ visible, currentPoints, onClose, onSpend }: SpendPointsModalProps) {
  const colors = useColors();
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [result, setResult] = useState<"idle" | "success" | "fail">("idle");
  const scaleAnim = React.useRef(new Animated.Value(1)).current;

  const selectedOption = OPTIONS.find((o) => o.id === selectedId);

  const handleConfirm = () => {
    if (!selectedOption) return;
    const ok = onSpend(selectedOption.cost);
    setResult(ok ? "success" : "fail");
    Animated.sequence([
      Animated.timing(scaleAnim, { toValue: 1.08, duration: 150, useNativeDriver: true }),
      Animated.timing(scaleAnim, { toValue: 1, duration: 200, useNativeDriver: true }),
    ]).start(() => {
      if (ok) {
        setTimeout(() => {
          setResult("idle");
          setSelectedId(null);
          onClose();
        }, 1200);
      } else {
        setTimeout(() => setResult("idle"), 1500);
      }
    });
  };

  return (
    <Modal visible={visible} transparent animationType="slide">
      <TouchableOpacity style={styles.overlay} activeOpacity={1} onPress={result === "idle" ? onClose : undefined}>
        <Animated.View
          style={[styles.sheet, { backgroundColor: "#181828", borderColor: "#2A2A42", transform: [{ scale: scaleAnim }] }]}
        >
          <View style={[styles.handle, { backgroundColor: "#2A2A42" }]} />

          {result === "success" ? (
            <View style={styles.resultBox}>
              <LinearGradient colors={["#00B38A", "#3B82F6"]} style={styles.resultIcon}>
                <Feather name="check" size={28} color="#fff" />
              </LinearGradient>
              <Text style={[styles.resultTitle, { fontFamily: "Poppins_700Bold" }]}>Time Unlocked!</Text>
              <Text style={[styles.resultSub, { fontFamily: "Poppins_400Regular" }]}>
                {selectedOption?.minutes} extra minutes added
              </Text>
            </View>
          ) : result === "fail" ? (
            <View style={styles.resultBox}>
              <LinearGradient colors={["#EF4444", "#F59E0B"]} style={styles.resultIcon}>
                <Feather name="x" size={28} color="#fff" />
              </LinearGradient>
              <Text style={[styles.resultTitle, { fontFamily: "Poppins_700Bold" }]}>Not Enough Points</Text>
              <Text style={[styles.resultSub, { fontFamily: "Poppins_400Regular" }]}>
                You need {selectedOption?.cost} points. Earn more by staying within limits.
              </Text>
            </View>
          ) : (
            <>
              <View style={styles.titleRow}>
                <LinearGradient colors={["#8B5CF6", "#3B82F6"]} style={styles.titleIcon}>
                  <Feather name="clock" size={18} color="#fff" />
                </LinearGradient>
                <View>
                  <Text style={[styles.sheetTitle, { fontFamily: "Poppins_700Bold" }]}>Unlock Extra Time</Text>
                  <Text style={[styles.sheetSub, { fontFamily: "Poppins_400Regular" }]}>
                    You have {currentPoints} strike points
                  </Text>
                </View>
              </View>

              <View style={styles.optionsCol}>
                {OPTIONS.map((opt) => {
                  const isSelected = selectedId === opt.id;
                  const canAfford = currentPoints >= opt.cost;
                  return (
                    <Pressable
                      key={opt.id}
                      style={[
                        styles.optionCard,
                        { opacity: canAfford ? 1 : 0.45 },
                      ]}
                      onPress={() => canAfford && setSelectedId(opt.id)}
                    >
                      {isSelected ? (
                        <LinearGradient
                          colors={opt.gradientColors}
                          start={{ x: 0, y: 0 }}
                          end={{ x: 1, y: 0 }}
                          style={[StyleSheet.absoluteFill, { borderRadius: 16 }]}
                        />
                      ) : (
                        <View style={[StyleSheet.absoluteFill, { borderRadius: 16, backgroundColor: "#1E1E2E", borderWidth: 1, borderColor: "#2A2A42" }]} />
                      )}
                      <View style={styles.optionLeft}>
                        <Text style={[styles.optionMin, { color: "#fff", fontFamily: "Poppins_700Bold" }]}>
                          +{opt.minutes}m
                        </Text>
                        <Text style={[styles.optionLabel, { color: isSelected ? "rgba(255,255,255,0.85)" : "#888", fontFamily: "Poppins_400Regular" }]}>
                          {opt.label}
                        </Text>
                      </View>
                      <View style={[styles.costBadge, { backgroundColor: isSelected ? "rgba(255,255,255,0.2)" : "#2A2A42" }]}>
                        <Feather name="star" size={11} color={isSelected ? "#fff" : "#888"} />
                        <Text style={[styles.costText, { color: isSelected ? "#fff" : "#888", fontFamily: "Poppins_700Bold" }]}>
                          {opt.cost}
                        </Text>
                      </View>
                    </Pressable>
                  );
                })}
              </View>

              <Pressable
                style={({ pressed }) => [styles.confirmBtn, { opacity: selectedId && !pressed ? 1 : 0.55 }]}
                onPress={handleConfirm}
                disabled={!selectedId}
              >
                <LinearGradient
                  colors={["#8B5CF6", "#3B82F6"]}
                  start={{ x: 0, y: 0 }}
                  end={{ x: 1, y: 0 }}
                  style={[StyleSheet.absoluteFill, { borderRadius: 16 }]}
                />
                <Feather name="unlock" size={18} color="#fff" />
                <Text style={[styles.confirmText, { color: "#fff", fontFamily: "Poppins_700Bold" }]}>
                  Confirm
                </Text>
              </Pressable>
            </>
          )}
        </Animated.View>
      </TouchableOpacity>
    </Modal>
  );
}

const styles = StyleSheet.create({
  overlay: {
    flex: 1,
    justifyContent: "flex-end",
    backgroundColor: "rgba(0,0,0,0.7)",
  },
  sheet: {
    borderTopLeftRadius: 28,
    borderTopRightRadius: 28,
    borderWidth: 1,
    padding: 24,
    gap: 20,
  },
  handle: {
    width: 40,
    height: 4,
    borderRadius: 2,
    alignSelf: "center",
  },
  titleRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 12,
  },
  titleIcon: {
    width: 42,
    height: 42,
    borderRadius: 13,
    alignItems: "center",
    justifyContent: "center",
  },
  sheetTitle: {
    fontSize: 18,
    color: "#fff",
  },
  sheetSub: {
    fontSize: 12,
    color: "#888",
    marginTop: 2,
  },
  optionsCol: {
    gap: 10,
  },
  optionCard: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    padding: 16,
    borderRadius: 16,
    overflow: "hidden",
  },
  optionLeft: { gap: 2 },
  optionMin: { fontSize: 20 },
  optionLabel: { fontSize: 12 },
  costBadge: {
    flexDirection: "row",
    alignItems: "center",
    gap: 4,
    paddingHorizontal: 10,
    paddingVertical: 5,
    borderRadius: 10,
  },
  costText: { fontSize: 13 },
  confirmBtn: {
    height: 52,
    borderRadius: 16,
    overflow: "hidden",
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 8,
  },
  confirmText: { fontSize: 16 },
  resultBox: {
    alignItems: "center",
    gap: 12,
    paddingVertical: 20,
  },
  resultIcon: {
    width: 70,
    height: 70,
    borderRadius: 22,
    alignItems: "center",
    justifyContent: "center",
  },
  resultTitle: {
    fontSize: 20,
    color: "#fff",
  },
  resultSub: {
    fontSize: 13,
    color: "#888",
    textAlign: "center",
    lineHeight: 20,
  },
});

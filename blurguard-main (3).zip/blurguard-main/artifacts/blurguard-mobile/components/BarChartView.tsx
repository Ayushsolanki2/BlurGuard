import React, { useEffect, useRef } from "react";
import { View, Text, StyleSheet, ScrollView, Animated, Easing } from "react-native";
import { useColors } from "@/hooks/useColors";

interface BarChartViewProps {
  data: number[];
  labels: string[];
  height?: number;
}

function BarItem({ value, maxValue, label, index, accentColor, mutedColor, textColor, mutedTextColor }: {
  value: number;
  maxValue: number;
  label: string;
  index: number;
  accentColor: string;
  mutedColor: string;
  textColor: string;
  mutedTextColor: string;
}) {
  const heightAnim = useRef(new Animated.Value(0)).current;
  const isMax = value === maxValue;

  useEffect(() => {
    Animated.timing(heightAnim, {
      toValue: value / maxValue,
      duration: 800,
      delay: index * 60,
      easing: Easing.out(Easing.quad),
      useNativeDriver: false,
    }).start();
  }, []);

  return (
    <View style={styles.barWrapper}>
      <Text style={[styles.barValue, { color: isMax ? accentColor : mutedTextColor, fontSize: 9 }]}>
        {value}
      </Text>
      <View style={[styles.barTrack, { backgroundColor: mutedColor }]}>
        <Animated.View
          style={[
            styles.barFill,
            {
              backgroundColor: isMax ? accentColor : "#8B5CF6",
              height: heightAnim.interpolate({
                inputRange: [0, 1],
                outputRange: ["0%", `${(value / maxValue) * 100}%`],
              }),
            },
          ]}
        />
      </View>
      <Text style={[styles.barLabel, { color: mutedTextColor }]}>{label}</Text>
    </View>
  );
}

export function BarChartView({ data, labels, height = 140 }: BarChartViewProps) {
  const colors = useColors();
  const maxValue = Math.max(...data);

  return (
    <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.container}>
      {data.map((value, index) => (
        <BarItem
          key={index}
          value={value}
          maxValue={maxValue}
          label={labels[index]}
          index={index}
          accentColor={colors.secondary}
          mutedColor={colors.muted}
          textColor={colors.foreground}
          mutedTextColor={colors.mutedForeground}
        />
      ))}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection: "row",
    alignItems: "flex-end",
    paddingHorizontal: 4,
    paddingBottom: 4,
    gap: 6,
  },
  barWrapper: {
    alignItems: "center",
    gap: 4,
    width: 36,
  },
  barValue: {
    fontFamily: "Poppins_400Regular",
  },
  barTrack: {
    width: 20,
    height: 120,
    borderRadius: 6,
    justifyContent: "flex-end",
    overflow: "hidden",
  },
  barFill: {
    width: "100%",
    borderRadius: 6,
  },
  barLabel: {
    fontSize: 9,
    fontFamily: "Poppins_400Regular",
    textAlign: "center",
  },
});

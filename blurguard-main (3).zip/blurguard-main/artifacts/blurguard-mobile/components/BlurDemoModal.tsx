import { BlurView } from "expo-blur";
import React, { useEffect, useRef, useState } from "react";
import {
  Animated,
  Easing,
  Modal,
  Platform,
  Pressable,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from "react-native";
import { Feather } from "@expo/vector-icons";
import { useColors } from "@/hooks/useColors";

interface BlurDemoModalProps {
  visible: boolean;
  onClose: () => void;
}

type DemoStage = "idle" | "warning" | "blurring" | "blocked";

export function BlurDemoModal({ visible, onClose }: BlurDemoModalProps) {
  const colors = useColors();
  const [stage, setStage] = useState<DemoStage>("idle");
  const blurAnim = useRef(new Animated.Value(0)).current;
  const opacityAnim = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    if (!visible) {
      setStage("idle");
      blurAnim.setValue(0);
      opacityAnim.setValue(0);
    }
  }, [visible]);

  const startDemo = () => {
    setStage("warning");
    setTimeout(() => {
      setStage("blurring");
      Animated.timing(blurAnim, {
        toValue: 1,
        duration: 2500,
        easing: Easing.out(Easing.quad),
        useNativeDriver: false,
      }).start(() => {
        setStage("blocked");
        Animated.timing(opacityAnim, {
          toValue: 1,
          duration: 400,
          useNativeDriver: false,
        }).start();
      });
    }, 1800);
  };

  const reset = () => {
    setStage("idle");
    blurAnim.setValue(0);
    opacityAnim.setValue(0);
  };

  const blurIntensity = blurAnim.interpolate({
    inputRange: [0, 1],
    outputRange: [0, 80],
  });

  return (
    <Modal visible={visible} transparent animationType="slide">
      <TouchableOpacity style={styles.overlay} activeOpacity={1} onPress={stage === "idle" ? onClose : undefined}>
        <View style={[styles.sheet, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <View style={[styles.handle, { backgroundColor: colors.border }]} />
          <Text style={[styles.title, { color: colors.foreground, fontFamily: "Poppins_700Bold" }]}>
            Blur Effect Demo
          </Text>
          <Text style={[styles.subtitle, { color: colors.mutedForeground, fontFamily: "Poppins_400Regular" }]}>
            This is how BlurGuard discourages over-use after your limit is reached.
          </Text>

          {/* Mock app screen */}
          <View style={[styles.mockScreen, { backgroundColor: colors.muted, borderColor: colors.border }]}>
            {/* Fake content */}
            <View style={styles.mockContent}>
              <View style={[styles.mockAvatar, { backgroundColor: "#E1306C" }]} />
              <View style={styles.mockLines}>
                <View style={[styles.mockLine, { backgroundColor: colors.border, width: "70%" }]} />
                <View style={[styles.mockLine, { backgroundColor: colors.border, width: "50%" }]} />
              </View>
            </View>
            {[1, 2].map((i) => (
              <View key={i} style={[styles.mockPost, { backgroundColor: colors.card }]} />
            ))}

            {/* Animated blur overlay */}
            {stage !== "idle" && (
              Platform.OS === "ios" ? (
                <Animated.View style={[StyleSheet.absoluteFill, { opacity: blurAnim }]}>
                  <BlurView intensity={80} tint="dark" style={StyleSheet.absoluteFill} />
                </Animated.View>
              ) : (
                <Animated.View
                  style={[
                    StyleSheet.absoluteFill,
                    {
                      backgroundColor: "rgba(13,13,26,0.7)",
                      opacity: blurAnim,
                    },
                  ]}
                />
              )
            )}

            {/* Warning banner */}
            {stage === "warning" && (
              <View style={[styles.warningBanner, { backgroundColor: "#F59E0B" }]}>
                <Feather name="alert-triangle" size={14} color="#fff" />
                <Text style={[styles.warningText, { fontFamily: "Poppins_600SemiBold" }]}>
                  Limit almost reached
                </Text>
              </View>
            )}

            {/* Blocked overlay */}
            {stage === "blocked" && (
              <Animated.View
                style={[styles.blockedOverlay, { opacity: opacityAnim, backgroundColor: colors.background + "EE" }]}
              >
                <View style={[styles.blockedIcon, { backgroundColor: colors.primary + "20" }]}>
                  <Feather name="eye-off" size={28} color={colors.primary} />
                </View>
                <Text style={[styles.blockedTitle, { color: colors.foreground, fontFamily: "Poppins_700Bold" }]}>
                  Limit Reached
                </Text>
                <Text style={[styles.blockedSub, { color: colors.mutedForeground, fontFamily: "Poppins_400Regular" }]}>
                  Instagram is temporarily blocked. Take a break.
                </Text>
              </Animated.View>
            )}
          </View>

          {/* Flow steps */}
          <View style={styles.flowRow}>
            {(["Active", "Warning", "Blurring", "Blocked"] as const).map((label, i) => {
              const stageIndex = ["idle", "warning", "blurring", "blocked"].indexOf(stage);
              const active = i <= stageIndex;
              return (
                <React.Fragment key={label}>
                  <View style={[styles.flowStep, { backgroundColor: active ? colors.primary : colors.muted }]}>
                    <Text style={[styles.flowLabel, { color: active ? colors.primaryForeground : colors.mutedForeground, fontFamily: "Poppins_400Regular" }]}>
                      {label}
                    </Text>
                  </View>
                  {i < 3 && <View style={[styles.flowLine, { backgroundColor: active && i < stageIndex ? colors.primary : colors.border }]} />}
                </React.Fragment>
              );
            })}
          </View>

          {/* Buttons */}
          <View style={styles.btnRow}>
            {stage === "idle" && (
              <Pressable style={[styles.btn, { backgroundColor: colors.primary }]} onPress={startDemo}>
                <Feather name="play" size={16} color="#fff" />
                <Text style={[styles.btnText, { color: "#fff", fontFamily: "Poppins_600SemiBold" }]}>
                  Start Demo
                </Text>
              </Pressable>
            )}
            {stage === "blocked" && (
              <Pressable style={[styles.btn, { backgroundColor: colors.secondary }]} onPress={reset}>
                <Feather name="refresh-cw" size={16} color="#fff" />
                <Text style={[styles.btnText, { color: "#fff", fontFamily: "Poppins_600SemiBold" }]}>
                  Replay
                </Text>
              </Pressable>
            )}
            <Pressable style={[styles.btn, { backgroundColor: colors.muted }]} onPress={onClose}>
              <Text style={[styles.btnText, { color: colors.foreground, fontFamily: "Poppins_400Regular" }]}>
                Close
              </Text>
            </Pressable>
          </View>
        </View>
      </TouchableOpacity>
    </Modal>
  );
}

const styles = StyleSheet.create({
  overlay: {
    flex: 1,
    justifyContent: "flex-end",
    backgroundColor: "rgba(0,0,0,0.6)",
  },
  sheet: {
    borderTopLeftRadius: 28,
    borderTopRightRadius: 28,
    borderWidth: 1,
    padding: 24,
    gap: 14,
  },
  handle: {
    width: 40,
    height: 4,
    borderRadius: 2,
    alignSelf: "center",
    marginBottom: 4,
  },
  title: {
    fontSize: 20,
  },
  subtitle: {
    fontSize: 13,
    lineHeight: 20,
  },
  mockScreen: {
    borderRadius: 16,
    borderWidth: 1,
    overflow: "hidden",
    height: 180,
    padding: 14,
    gap: 10,
  },
  mockContent: {
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
  },
  mockAvatar: {
    width: 36,
    height: 36,
    borderRadius: 18,
  },
  mockLines: {
    flex: 1,
    gap: 6,
  },
  mockLine: {
    height: 10,
    borderRadius: 5,
  },
  mockPost: {
    height: 48,
    borderRadius: 10,
  },
  warningBanner: {
    position: "absolute",
    top: 0,
    left: 0,
    right: 0,
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
    padding: 10,
  },
  warningText: {
    color: "#fff",
    fontSize: 12,
  },
  blockedOverlay: {
    ...StyleSheet.absoluteFillObject,
    alignItems: "center",
    justifyContent: "center",
    borderRadius: 16,
    gap: 8,
    padding: 20,
  },
  blockedIcon: {
    width: 60,
    height: 60,
    borderRadius: 20,
    alignItems: "center",
    justifyContent: "center",
    marginBottom: 4,
  },
  blockedTitle: {
    fontSize: 18,
  },
  blockedSub: {
    fontSize: 12,
    textAlign: "center",
    lineHeight: 18,
  },
  flowRow: {
    flexDirection: "row",
    alignItems: "center",
  },
  flowStep: {
    paddingHorizontal: 8,
    paddingVertical: 5,
    borderRadius: 8,
  },
  flowLabel: {
    fontSize: 10,
  },
  flowLine: {
    flex: 1,
    height: 2,
    borderRadius: 1,
    marginHorizontal: 2,
  },
  btnRow: {
    flexDirection: "row",
    gap: 10,
  },
  btn: {
    flex: 1,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 8,
    paddingVertical: 14,
    borderRadius: 14,
  },
  btnText: {
    fontSize: 15,
  },
});

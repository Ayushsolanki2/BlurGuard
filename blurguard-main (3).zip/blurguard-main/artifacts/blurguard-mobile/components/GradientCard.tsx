import { LinearGradient } from "expo-linear-gradient";
import React from "react";
import { StyleSheet, View, ViewStyle } from "react-native";
import { useColors } from "@/hooks/useColors";

interface GradientCardProps {
  children: React.ReactNode;
  colors?: [string, string, ...string[]];
  style?: ViewStyle;
  padding?: number;
  borderRadius?: number;
  start?: { x: number; y: number };
  end?: { x: number; y: number };
}

export function GradientCard({
  children,
  colors: gradColors,
  style,
  padding = 20,
  borderRadius = 24,
  start = { x: 0, y: 0 },
  end = { x: 1, y: 1 },
}: GradientCardProps) {
  const colors = useColors();
  const resolvedColors = gradColors ?? ([colors.gradientStart, colors.gradientMid] as [string, string]);

  return (
    <LinearGradient
      colors={resolvedColors}
      start={start}
      end={end}
      style={[{ borderRadius, padding }, style]}
    >
      {children}
    </LinearGradient>
  );
}

const styles = StyleSheet.create({});

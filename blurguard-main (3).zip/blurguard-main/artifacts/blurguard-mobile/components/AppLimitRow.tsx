import React, { useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  Pressable,
  Switch,
  Modal,
  TouchableOpacity,
} from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import { Feather } from "@expo/vector-icons";
import { useColors } from "@/hooks/useColors";
import { formatMinutes } from "@/data/mockData";
import type { AppUsage } from "@/data/mockData";
import { AppIconSVG } from "@/components/AppIconSVG";

const LIMIT_OPTIONS = [15, 30, 45, 60, 90, 120, 180];

interface AppLimitRowProps {
  app: AppUsage;
  limitMinutes: number;
  enabled: boolean;
  onToggle: (enabled: boolean) => void;
  onLimitChange: (minutes: number) => void;
}

export function AppLimitRow({ app, limitMinutes, enabled, onToggle, onLimitChange }: AppLimitRowProps) {
  const colors = useColors();
  const [pickerVisible, setPickerVisible] = useState(false);

  return (
    <>
      <View style={[styles.row, { borderBottomColor: colors.border }]}>
        <View style={styles.iconWrap}>
          <AppIconSVG appId={app.id} size={44} />
        </View>
        <View style={styles.info}>
          <Text style={[styles.appName, { color: colors.foreground, fontFamily: "Poppins_600SemiBold" }]}>
            {app.name}
          </Text>
          <Pressable onPress={() => enabled && setPickerVisible(true)}>
            <View style={styles.limitLabelRow}>
              <Text style={[styles.limitLabel, { color: enabled ? colors.primary : colors.mutedForeground, fontFamily: "Poppins_400Regular" }]}>
                {enabled ? formatMinutes(limitMinutes) + " / day" : "No limit set"}
              </Text>
              {enabled && (
                <Feather name="edit-2" size={11} color={colors.primary} style={{ marginLeft: 4 }} />
              )}
            </View>
          </Pressable>
        </View>
        <Switch
          value={enabled}
          onValueChange={onToggle}
          trackColor={{ false: colors.muted, true: colors.primary + "80" }}
          thumbColor={enabled ? colors.primary : colors.mutedForeground}
        />
      </View>

      <Modal visible={pickerVisible} transparent animationType="slide">
        <TouchableOpacity style={styles.overlay} activeOpacity={1} onPress={() => setPickerVisible(false)}>
          <View style={[styles.sheet, { backgroundColor: colors.card, borderColor: colors.border }]}>
            <View style={[styles.handle, { backgroundColor: colors.border }]} />

            <View style={styles.sheetHeader}>
              <View style={styles.iconWrap}>
                <AppIconSVG appId={app.id} size={40} />
              </View>
              <View>
                <Text style={[styles.sheetTitle, { color: colors.foreground, fontFamily: "Poppins_700Bold" }]}>
                  {app.name} Limit
                </Text>
                <Text style={[styles.sheetSub, { color: colors.mutedForeground, fontFamily: "Poppins_400Regular" }]}>
                  Daily time limit for this app
                </Text>
              </View>
            </View>

            <View style={styles.optionsGrid}>
              {LIMIT_OPTIONS.map((opt) => (
                <Pressable
                  key={opt}
                  onPress={() => {
                    onLimitChange(opt);
                    setPickerVisible(false);
                  }}
                >
                  {limitMinutes === opt ? (
                    <LinearGradient
                      colors={["#8B5CF6", "#3B82F6"]}
                      start={{ x: 0, y: 0 }}
                      end={{ x: 1, y: 0 }}
                      style={styles.optionBtn}
                    >
                      <Text style={[styles.optionText, { color: "#fff", fontFamily: "Poppins_700Bold" }]}>
                        {formatMinutes(opt)}
                      </Text>
                    </LinearGradient>
                  ) : (
                    <View style={[styles.optionBtn, { backgroundColor: colors.muted, borderColor: colors.border, borderWidth: 1.5 }]}>
                      <Text style={[styles.optionText, { color: colors.foreground, fontFamily: "Poppins_400Regular" }]}>
                        {formatMinutes(opt)}
                      </Text>
                    </View>
                  )}
                </Pressable>
              ))}
            </View>
          </View>
        </TouchableOpacity>
      </Modal>
    </>
  );
}

const styles = StyleSheet.create({
  row: {
    flexDirection: "row",
    alignItems: "center",
    paddingVertical: 13,
    borderBottomWidth: StyleSheet.hairlineWidth,
    gap: 12,
  },
  iconWrap: { borderRadius: 12, overflow: "hidden" },
  info: { flex: 1, gap: 3 },
  appName: { fontSize: 14 },
  limitLabelRow: { flexDirection: "row", alignItems: "center" },
  limitLabel: { fontSize: 12 },
  overlay: {
    flex: 1,
    justifyContent: "flex-end",
    backgroundColor: "rgba(0,0,0,0.45)",
  },
  sheet: {
    borderTopLeftRadius: 28,
    borderTopRightRadius: 28,
    borderWidth: 1,
    padding: 24,
    gap: 20,
  },
  handle: { width: 40, height: 4, borderRadius: 2, alignSelf: "center" },
  sheetHeader: { flexDirection: "row", alignItems: "center", gap: 14 },
  sheetTitle: { fontSize: 18 },
  sheetSub: { fontSize: 12, marginTop: 2 },
  optionsGrid: { flexDirection: "row", flexWrap: "wrap", gap: 10 },
  optionBtn: {
    paddingHorizontal: 18,
    paddingVertical: 11,
    borderRadius: 14,
    alignItems: "center",
  },
  optionText: { fontSize: 14 },
});

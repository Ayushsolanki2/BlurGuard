export interface AppUsage {
  id: string;
  name: string;
  iconLetter: string;
  iconColor: string;
  usageMinutes: number;
  limitMinutes: number;
  percentageOfDay: number;
}

export interface DailyStats {
  totalMinutes: number;
  goalMinutes: number;
  yesterdayMinutes: number;
  unlocks: number;
  notifications: number;
  nightMinutes: number;
}

export interface InsightItem {
  id: string;
  title: string;
  description: string;
  accentColor: string;
  iconName: string;
  severity: "warning" | "caution" | "positive" | "info";
}

export interface AISuggestion {
  id: string;
  headline: string;
  body: string;
  iconName: string;
  gradientColors: [string, string];
}

export interface StreakGoal {
  id: string;
  label: string;
  completed: boolean;
  iconName: string;
}

export interface LeaderboardEntry {
  id: string;
  name: string;
  points: number;
  rank: number;
  isCurrentUser: boolean;
  avatarLetter: string;
  avatarColor: string;
}

export interface BarChartItem {
  label: string;
  shortLabel: string;
  value: number;
  color: string;
  gradientColors: [string, string];
}

export interface AchievementBadge {
  id: string;
  title: string;
  description: string;
  iconName: string;
  earned: boolean;
  gradientColors: [string, string];
  points: number;
}

export interface StrikeHistoryItem {
  label: string;
  change: number;
  reason: string;
}

export const dailyStats: DailyStats = {
  totalMinutes: 342,
  goalMinutes: 480,
  yesterdayMinutes: 319,
  unlocks: 47,
  notifications: 132,
  nightMinutes: 70,
};

export const appUsageList: AppUsage[] = [
  { id: "1", name: "Instagram", iconLetter: "I", iconColor: "#E1306C", usageMinutes: 135, limitMinutes: 60, percentageOfDay: 40 },
  { id: "2", name: "YouTube", iconLetter: "Y", iconColor: "#FF4444", usageMinutes: 90, limitMinutes: 120, percentageOfDay: 27 },
  { id: "3", name: "WhatsApp", iconLetter: "W", iconColor: "#25D366", usageMinutes: 45, limitMinutes: 60, percentageOfDay: 13 },
  { id: "4", name: "Chrome", iconLetter: "C", iconColor: "#4285F4", usageMinutes: 32, limitMinutes: 60, percentageOfDay: 9 },
  { id: "5", name: "Spotify", iconLetter: "S", iconColor: "#1DB954", usageMinutes: 28, limitMinutes: 60, percentageOfDay: 8 },
  { id: "6", name: "Gmail", iconLetter: "G", iconColor: "#EA4335", usageMinutes: 12, limitMinutes: 60, percentageOfDay: 3 },
];

export const topApps = appUsageList.slice(0, 3);
export const mostUsedApps = appUsageList.slice(0, 3);
export const leastUsedApps = appUsageList.slice(3).reverse();

export const todayBarData: BarChartItem[] = [
  { label: "Instagram", shortLabel: "IG", value: 135, color: "#E1306C", gradientColors: ["#E1306C", "#FF6B8A"] },
  { label: "YouTube", shortLabel: "YT", value: 90, color: "#FF4444", gradientColors: ["#FF4444", "#FF8C00"] },
  { label: "WhatsApp", shortLabel: "WA", value: 45, color: "#25D366", gradientColors: ["#25D366", "#00D4AA"] },
  { label: "Chrome", shortLabel: "CR", value: 32, color: "#4285F4", gradientColors: ["#4285F4", "#8B5CF6"] },
  { label: "Spotify", shortLabel: "SP", value: 28, color: "#1DB954", gradientColors: ["#1DB954", "#00D4AA"] },
  { label: "Gmail", shortLabel: "GM", value: 12, color: "#EA4335", gradientColors: ["#EA4335", "#F59E0B"] },
];

export const weekBarData: BarChartItem[] = [
  { label: "Instagram", shortLabel: "IG", value: 890, color: "#E1306C", gradientColors: ["#E1306C", "#FF6B8A"] },
  { label: "YouTube", shortLabel: "YT", value: 680, color: "#FF4444", gradientColors: ["#FF4444", "#FF8C00"] },
  { label: "WhatsApp", shortLabel: "WA", value: 320, color: "#25D366", gradientColors: ["#25D366", "#00D4AA"] },
  { label: "Chrome", shortLabel: "CR", value: 210, color: "#4285F4", gradientColors: ["#4285F4", "#8B5CF6"] },
  { label: "Spotify", shortLabel: "SP", value: 190, color: "#1DB954", gradientColors: ["#1DB954", "#00D4AA"] },
  { label: "Gmail", shortLabel: "GM", value: 85, color: "#EA4335", gradientColors: ["#EA4335", "#F59E0B"] },
];

export const aiSuggestions: AISuggestion[] = [
  {
    id: "s1",
    headline: "Social media check-in",
    body: "You've spent 2 hours scrolling today. That's enough time to read 40 pages, take a walk, or learn something new.",
    iconName: "sun",
    gradientColors: ["#8B5CF6", "#3B82F6"],
  },
  {
    id: "s2",
    headline: "Protect your sleep",
    body: "Screen light after 10 PM delays sleep by up to 1 hour. Try dimming your phone or switching to reading mode.",
    iconName: "moon",
    gradientColors: ["#6366F1", "#8B5CF6"],
  },
  {
    id: "s3",
    headline: "20-20-20 rule",
    body: "Every 20 minutes, look at something 20 feet away for 20 seconds. Your eyes will thank you.",
    iconName: "eye",
    gradientColors: ["#00B38A", "#00D4AA"],
  },
];

export const insights: InsightItem[] = [
  {
    id: "1",
    title: "Instagram Overuse",
    description: "You spent 2h 15m on Instagram, 45 min above your average.",
    accentColor: "#FF6B6B",
    iconName: "alert-circle",
    severity: "warning",
  },
  {
    id: "2",
    title: "Take a Break",
    description: "You have been on your phone for 90 minutes straight.",
    accentColor: "#F59E0B",
    iconName: "clock",
    severity: "caution",
  },
  {
    id: "3",
    title: "Late Night Usage",
    description: "Screen time after 11 PM increased by 40% this week.",
    accentColor: "#6366F1",
    iconName: "moon",
    severity: "info",
  },
  {
    id: "4",
    title: "Productivity Win",
    description: "Focus app usage up 30% today. Keep it up.",
    accentColor: "#00D4AA",
    iconName: "trending-up",
    severity: "positive",
  },
];

export const todayGoals: StreakGoal[] = [
  { id: "g1", label: "Stay under 6h screen time", completed: true, iconName: "smartphone" },
  { id: "g2", label: "30-min focus session", completed: true, iconName: "target" },
  { id: "g3", label: "No phone after 10 PM", completed: false, iconName: "moon" },
  { id: "g4", label: "Take 3 screen breaks", completed: false, iconName: "coffee" },
];

export const leaderboard: LeaderboardEntry[] = [
  { id: "l1", name: "Sarah K.", points: 1250, rank: 1, isCurrentUser: false, avatarLetter: "S", avatarColor: "#E1306C" },
  { id: "l2", name: "Mike R.", points: 980, rank: 2, isCurrentUser: false, avatarLetter: "M", avatarColor: "#3B82F6" },
  { id: "l3", name: "You", points: 420, rank: 3, isCurrentUser: true, avatarLetter: "Y", avatarColor: "#8B5CF6" },
  { id: "l4", name: "Emma L.", points: 380, rank: 4, isCurrentUser: false, avatarLetter: "E", avatarColor: "#00D4AA" },
  { id: "l5", name: "James T.", points: 290, rank: 5, isCurrentUser: false, avatarLetter: "J", avatarColor: "#F59E0B" },
];

export const achievementBadges: AchievementBadge[] = [
  { id: "b1", title: "7-Day Streak", description: "7 days under limit", iconName: "zap", earned: true, gradientColors: ["#F59E0B", "#EF4444"], points: 100 },
  { id: "b2", title: "Under Limit", description: "Stayed within limits today", iconName: "check-circle", earned: true, gradientColors: ["#8B5CF6", "#3B82F6"], points: 50 },
  { id: "b3", title: "Focus Master", description: "5 focus sessions in a week", iconName: "target", earned: false, gradientColors: ["#00B38A", "#00D4AA"], points: 80 },
  { id: "b4", title: "Early Bird", description: "No screen before 8 AM", iconName: "sun", earned: false, gradientColors: ["#F59E0B", "#EA4335"], points: 60 },
];

export const strikeHistory: StrikeHistoryItem[] = [
  { label: "Mon", change: 10, reason: "Stayed within limit" },
  { label: "Tue", change: 10, reason: "Stayed within limit" },
  { label: "Wed", change: 3, reason: "Near limit" },
  { label: "Thu", change: -5, reason: "Crossed limit" },
  { label: "Fri", change: 10, reason: "Stayed within limit" },
  { label: "Sat", change: 3, reason: "Near limit" },
  { label: "Sun", change: 3, reason: "Near limit" },
];

export const weeklyUsage = [4.5, 6.2, 5.8, 7.1, 5.2, 8.3, 5.7];
export const weeklyLimit = [8, 8, 8, 8, 8, 8, 8];
export const weekDays = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];

export function formatMinutes(minutes: number): string {
  const h = Math.floor(minutes / 60);
  const m = minutes % 60;
  if (h === 0) return `${m}m`;
  if (m === 0) return `${h}h`;
  return `${h}h ${m}m`;
}

export function getPercentage(value: number, total: number): number {
  return Math.round((value / total) * 100);
}

export function getGreeting(): string {
  const hour = new Date().getHours();
  if (hour < 12) return "Good Morning";
  if (hour < 17) return "Good Afternoon";
  return "Good Evening";
}

import { LinearGradient } from "expo-linear-gradient";
import React, { useEffect, useRef, useState } from "react";
import {
  Animated,
  Easing,
  Modal,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Switch,
  Text,
  TouchableOpacity,
  View,
} from "react-native";
import { Feather } from "@expo/vector-icons";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useColors } from "@/hooks/useColors";
import { GlassCard } from "@/components/GlassCard";
import { BlurDemoModal } from "@/components/BlurDemoModal";
import { AppIconSVG } from "@/components/AppIconSVG";
import { useFocus } from "@/context/FocusContext";
import { appUsageList, formatMinutes } from "@/data/mockData";

const LIMIT_OPTIONS = [15, 30, 45, 60, 90, 120];

export default function FocusScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const isWeb = Platform.OS === "web";
  const topPad = isWeb ? 67 : insets.top;

  const {
    isFocusModeActive,
    blurEnabled,
    appLimits,
    toggleFocusMode,
    toggleBlur,
    setAppLimit,
  } = useFocus();

  const [appLimitEnabled, setAppLimitEnabled] = useState(false);
  const [blurDemoVisible, setBlurDemoVisible] = useState(false);
  const [pickerApp, setPickerApp] = useState<string | null>(null);

  // Animate sub-options reveal when Focus Mode is active
  const expandAnim = useRef(new Animated.Value(0)).current;
  const subExpandAnim = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    Animated.timing(expandAnim, {
      toValue: isFocusModeActive ? 1 : 0,
      duration: 340,
      easing: Easing.out(Easing.cubic),
      useNativeDriver: false,
    }).start();
    if (!isFocusModeActive) setAppLimitEnabled(false);
  }, [isFocusModeActive]);

  useEffect(() => {
    Animated.timing(subExpandAnim, {
      toValue: appLimitEnabled ? 1 : 0,
      duration: 300,
      easing: Easing.out(Easing.cubic),
      useNativeDriver: false,
    }).start();
  }, [appLimitEnabled]);

  const pickerAppData = pickerApp ? appUsageList.find((a) => a.id === pickerApp) : null;
  const pickerLimit = pickerApp ? (appLimits.find((l) => l.appId === pickerApp)?.limitMinutes ?? 60) : 60;

  return (
    <View style={[styles.screen, { backgroundColor: colors.background }]}>
      <View
        style={[
          styles.header,
          { paddingTop: topPad + 8, backgroundColor: colors.background, borderBottomColor: colors.border },
        ]}
      >
        <Text style={[styles.headerTitle, { color: colors.foreground, fontFamily: "Poppins_700Bold" }]}>
          Focus Mode
        </Text>
      </View>

      <ScrollView
        contentContainerStyle={[styles.scroll, { paddingBottom: isWeb ? 100 : insets.bottom + 90 }]}
        showsVerticalScrollIndicator={false}
      >

        {/* ── Main Focus Toggle Card ─────────────────────────────────────── */}
        {isFocusModeActive ? (
          <LinearGradient
            colors={["#7C3AED", "#3B82F6"]}
            start={{ x: 0, y: 0 }}
            end={{ x: 1, y: 1 }}
            style={styles.heroCard}
          >
            <View style={styles.heroInner}>
              <View style={styles.heroLeft}>
                <View style={[styles.heroIcon, { backgroundColor: "rgba(255,255,255,0.2)" }]}>
                  <Feather name="target" size={24} color="#fff" />
                </View>
                <View>
                  <Text style={[styles.heroTitle, { color: "#fff", fontFamily: "Poppins_700Bold" }]}>
                    Focus Mode
                  </Text>
                  <View style={styles.activePill}>
                    <View style={styles.activeDot} />
                    <Text style={[styles.activePillText, { fontFamily: "Poppins_600SemiBold" }]}>Active</Text>
                  </View>
                </View>
              </View>
              <Switch
                value={isFocusModeActive}
                onValueChange={toggleFocusMode}
                trackColor={{ false: "rgba(255,255,255,0.3)", true: "rgba(255,255,255,0.55)" }}
                thumbColor="#fff"
              />
            </View>
            <Text style={[styles.heroSubtitle, { color: "rgba(255,255,255,0.8)", fontFamily: "Poppins_400Regular" }]}>
              App limits are being enforced. Tap the toggle to pause.
            </Text>
          </LinearGradient>
        ) : (
          <GlassCard padding={20} borderRadius={24}>
            <View style={styles.heroInner}>
              <View style={styles.heroLeft}>
                <View style={[styles.heroIcon, { backgroundColor: colors.primary + "18" }]}>
                  <Feather name="target" size={24} color={colors.primary} />
                </View>
                <View>
                  <Text style={[styles.heroTitle, { color: colors.foreground, fontFamily: "Poppins_700Bold" }]}>
                    Focus Mode
                  </Text>
                  <Text style={[styles.heroSub2, { color: colors.mutedForeground, fontFamily: "Poppins_400Regular" }]}>
                    Off — tap to activate
                  </Text>
                </View>
              </View>
              <Switch
                value={isFocusModeActive}
                onValueChange={toggleFocusMode}
                trackColor={{ false: colors.muted, true: colors.primary + "80" }}
                thumbColor={colors.mutedForeground}
              />
            </View>

            {/* What Focus Mode does — shown only when OFF */}
            <View style={[styles.infoBox, { backgroundColor: colors.muted, borderColor: colors.border }]}>
              {[
                { icon: "clock", text: "Set daily time limits per app" },
                { icon: "eye-off", text: "Blur & block when limits are reached" },
                { icon: "zap", text: "Earn Strike Points for staying on track" },
              ].map((item, i) => (
                <View key={i} style={styles.infoRow}>
                  <View style={[styles.infoIcon, { backgroundColor: colors.primary + "20" }]}>
                    <Feather name={item.icon as any} size={13} color={colors.primary} />
                  </View>
                  <Text style={[styles.infoText, { color: colors.mutedForeground, fontFamily: "Poppins_400Regular" }]}>
                    {item.text}
                  </Text>
                </View>
              ))}
            </View>
          </GlassCard>
        )}

        {/* ── Sub-options (animated, only when Focus is ON) ─────────────── */}
        <Animated.View style={{ opacity: expandAnim, overflow: "hidden" }}
          pointerEvents={isFocusModeActive ? "auto" : "none"}
        >

          {/* ── Set App Usage Limit toggle ─────────────────────────────── */}
          <GlassCard padding={18} borderRadius={20}>
            <View style={styles.optionRow}>
              <View style={[styles.optionIcon, { backgroundColor: colors.primary + "18" }]}>
                <Feather name="sliders" size={17} color={colors.primary} />
              </View>
              <View style={styles.optionText_}>
                <Text style={[styles.optionTitle, { color: colors.foreground, fontFamily: "Poppins_600SemiBold" }]}>
                  Set App Usage Limit
                </Text>
                <Text style={[styles.optionSub, { color: colors.mutedForeground, fontFamily: "Poppins_400Regular" }]}>
                  Set daily time limits for specific apps
                </Text>
              </View>
              <Switch
                value={appLimitEnabled}
                onValueChange={setAppLimitEnabled}
                trackColor={{ false: colors.muted, true: colors.primary + "80" }}
                thumbColor={appLimitEnabled ? colors.primary : colors.mutedForeground}
              />
            </View>

            {/* ── Per-App limit cards (animated reveal) ─────────────────── */}
            <Animated.View style={{ opacity: subExpandAnim, overflow: "hidden" }}
              pointerEvents={appLimitEnabled ? "auto" : "none"}
            >
              <View style={[styles.appsContainer, { borderColor: colors.border }]}>
                <Text style={[styles.appsHint, { color: colors.mutedForeground, fontFamily: "Poppins_400Regular" }]}>
                  Tap a time limit to change it
                </Text>
                {appUsageList.map((app, i) => {
                  const limit = appLimits.find((l) => l.appId === app.id);
                  const enabled = limit?.enabled ?? false;
                  const limitMins = limit?.limitMinutes ?? 60;
                  const isLast = i === appUsageList.length - 1;
                  return (
                    <View
                      key={app.id}
                      style={[
                        styles.appCard,
                        {
                          borderBottomColor: colors.border,
                          borderBottomWidth: isLast ? 0 : StyleSheet.hairlineWidth,
                          backgroundColor: enabled ? colors.primary + "0A" : "transparent",
                        },
                      ]}
                    >
                      <View style={styles.appIconWrap}>
                        <AppIconSVG appId={app.id} size={44} />
                      </View>
                      <View style={styles.appCardInfo}>
                        <Text style={[styles.appCardName, { color: colors.foreground, fontFamily: "Poppins_600SemiBold" }]}>
                          {app.name}
                        </Text>
                        <Text style={[styles.appCardUsage, { color: colors.mutedForeground, fontFamily: "Poppins_400Regular" }]}>
                          Used {formatMinutes(app.usageMinutes)} today
                        </Text>
                      </View>

                      {/* Limit time chips */}
                      {enabled ? (
                        <Pressable
                          onPress={() => setPickerApp(app.id)}
                          style={({ pressed }) => [styles.limitChip, {
                            backgroundColor: colors.primary,
                            opacity: pressed ? 0.85 : 1,
                          }]}
                        >
                          <Feather name="clock" size={11} color="#fff" />
                          <Text style={[styles.limitChipText, { color: "#fff", fontFamily: "Poppins_700Bold" }]}>
                            {formatMinutes(limitMins)}
                          </Text>
                        </Pressable>
                      ) : (
                        <Switch
                          value={enabled}
                          onValueChange={(val) => setAppLimit(app.id, limitMins, val)}
                          trackColor={{ false: colors.muted, true: colors.primary + "80" }}
                          thumbColor={enabled ? colors.primary : colors.mutedForeground}
                        />
                      )}

                      {enabled && (
                        <Switch
                          value={enabled}
                          onValueChange={(val) => setAppLimit(app.id, limitMins, val)}
                          trackColor={{ false: colors.muted, true: colors.primary + "80" }}
                          thumbColor={colors.primary}
                        />
                      )}
                    </View>
                  );
                })}
              </View>
            </Animated.View>
          </GlassCard>

          {/* ── Blur Effect toggle ─────────────────────────────────────── */}
          <GlassCard padding={18} borderRadius={20}>
            <View style={styles.optionRow}>
              <View style={[styles.optionIcon, { backgroundColor: colors.secondary + "18" }]}>
                <Feather name="eye-off" size={17} color={colors.secondary} />
              </View>
              <View style={styles.optionText_}>
                <Text style={[styles.optionTitle, { color: colors.foreground, fontFamily: "Poppins_600SemiBold" }]}>
                  Blur Effect
                </Text>
                <Text style={[styles.optionSub, { color: colors.mutedForeground, fontFamily: "Poppins_400Regular" }]}>
                  Gradually blurs apps when limit is reached
                </Text>
              </View>
              <Switch
                value={blurEnabled}
                onValueChange={toggleBlur}
                trackColor={{ false: colors.muted, true: colors.secondary + "80" }}
                thumbColor={blurEnabled ? colors.secondary : colors.mutedForeground}
              />
            </View>

            {/* Blur flow */}
            <View style={styles.blurFlowRow}>
              {[
                { label: "Normal", color: colors.secondary },
                { label: "Warning", color: colors.caution },
                { label: "Blur", color: colors.warning },
                { label: "Blocked", color: "#EF4444" },
              ].map((step, i) => (
                <React.Fragment key={step.label}>
                  <View style={[styles.flowChip, { backgroundColor: step.color + "18" }]}>
                    <Text style={[styles.flowChipText, { color: step.color, fontFamily: "Poppins_400Regular" }]}>
                      {step.label}
                    </Text>
                  </View>
                  {i < 3 && <Feather name="arrow-right" size={11} color={colors.mutedForeground} />}
                </React.Fragment>
              ))}
            </View>

            <Pressable
              style={({ pressed }) => [styles.demoBtn, { backgroundColor: colors.primary, opacity: pressed ? 0.85 : 1 }]}
              onPress={() => setBlurDemoVisible(true)}
            >
              <Feather name="play-circle" size={17} color="#fff" />
              <Text style={[styles.demoBtnText, { color: "#fff", fontFamily: "Poppins_600SemiBold" }]}>
                Try Blur Demo
              </Text>
            </Pressable>
          </GlassCard>

          {/* ── Notification Steps ─────────────────────────────────────── */}
          <GlassCard padding={18} borderRadius={20}>
            <View style={styles.sectionHeaderRow}>
              <View style={[styles.optionIcon, { backgroundColor: "#F59E0B20" }]}>
                <Feather name="bell" size={17} color="#F59E0B" />
              </View>
              <Text style={[styles.optionTitle, { color: colors.foreground, fontFamily: "Poppins_600SemiBold" }]}>
                Smart Notifications
              </Text>
            </View>
            {[
              { pct: "75%", label: "First warning: \"Limit almost reached\"", color: colors.caution },
              { pct: "100%", label: "Limit reached: \"App will blur now\"", color: "#EF4444" },
            ].map((step, i) => (
              <View key={i} style={[styles.notifRow, { borderTopColor: colors.border }]}>
                <View style={[styles.notifDot, { backgroundColor: step.color }]} />
                <Text style={[styles.notifPct, { color: step.color, fontFamily: "Poppins_700Bold" }]}>{step.pct}</Text>
                <Text style={[styles.notifLabel, { color: colors.mutedForeground, fontFamily: "Poppins_400Regular" }]}>
                  {step.label}
                </Text>
              </View>
            ))}
          </GlassCard>
        </Animated.View>
      </ScrollView>

      {/* ── Time Picker Modal ──────────────────────────────────────────────── */}
      <Modal visible={!!pickerApp} transparent animationType="slide">
        <TouchableOpacity
          style={styles.modalOverlay}
          activeOpacity={1}
          onPress={() => setPickerApp(null)}
        >
          <View style={[styles.sheet, { backgroundColor: colors.card, borderColor: colors.border }]}>
            <View style={[styles.sheetHandle, { backgroundColor: colors.border }]} />

            {pickerAppData && (
              <View style={styles.sheetHeader}>
                <View style={styles.appIconWrap}>
                  <AppIconSVG appId={pickerAppData.id} size={46} />
                </View>
                <View>
                  <Text style={[styles.sheetTitle, { color: colors.foreground, fontFamily: "Poppins_700Bold" }]}>
                    {pickerAppData.name}
                  </Text>
                  <Text style={[styles.sheetSub, { color: colors.mutedForeground, fontFamily: "Poppins_400Regular" }]}>
                    Choose a daily time limit
                  </Text>
                </View>
              </View>
            )}

            <View style={styles.pickerGrid}>
              {LIMIT_OPTIONS.map((opt) => {
                const isSelected = opt === pickerLimit;
                return (
                  <Pressable
                    key={opt}
                    onPress={() => {
                      if (pickerApp) {
                        const limit = appLimits.find((l) => l.appId === pickerApp);
                        setAppLimit(pickerApp, opt, limit?.enabled ?? true);
                      }
                      setPickerApp(null);
                    }}
                  >
                    {isSelected ? (
                      <LinearGradient
                        colors={["#8B5CF6", "#3B82F6"]}
                        start={{ x: 0, y: 0 }}
                        end={{ x: 1, y: 0 }}
                        style={styles.pickerChip}
                      >
                        <Feather name="clock" size={13} color="#fff" />
                        <Text style={[styles.pickerChipText, { color: "#fff", fontFamily: "Poppins_700Bold" }]}>
                          {formatMinutes(opt)}
                        </Text>
                      </LinearGradient>
                    ) : (
                      <View style={[styles.pickerChip, { backgroundColor: colors.muted, borderColor: colors.border, borderWidth: 1.5 }]}>
                        <Text style={[styles.pickerChipText, { color: colors.foreground, fontFamily: "Poppins_400Regular" }]}>
                          {formatMinutes(opt)}
                        </Text>
                      </View>
                    )}
                  </Pressable>
                );
              })}
            </View>
          </View>
        </TouchableOpacity>
      </Modal>

      <BlurDemoModal visible={blurDemoVisible} onClose={() => setBlurDemoVisible(false)} />
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1 },
  header: { paddingHorizontal: 20, paddingBottom: 12, borderBottomWidth: StyleSheet.hairlineWidth },
  headerTitle: { fontSize: 24, lineHeight: 32 },
  scroll: { paddingHorizontal: 16, paddingTop: 16, gap: 14 },

  heroCard: { borderRadius: 24, padding: 20, gap: 12 },
  heroInner: { flexDirection: "row", alignItems: "center", justifyContent: "space-between" },
  heroLeft: { flexDirection: "row", alignItems: "center", gap: 14, flex: 1 },
  heroIcon: { width: 48, height: 48, borderRadius: 15, alignItems: "center", justifyContent: "center" },
  heroTitle: { fontSize: 18 },
  heroSub2: { fontSize: 12, marginTop: 2 },
  heroSubtitle: { fontSize: 13, lineHeight: 19 },
  activePill: { flexDirection: "row", alignItems: "center", gap: 5, marginTop: 3 },
  activeDot: { width: 7, height: 7, borderRadius: 4, backgroundColor: "#4ADE80" },
  activePillText: { fontSize: 12, color: "#4ADE80" },

  infoBox: {
    borderRadius: 14,
    borderWidth: 1,
    padding: 14,
    marginTop: 14,
    gap: 10,
  },
  infoRow: { flexDirection: "row", alignItems: "center", gap: 10 },
  infoIcon: { width: 28, height: 28, borderRadius: 8, alignItems: "center", justifyContent: "center", flexShrink: 0 },
  infoText: { flex: 1, fontSize: 13, lineHeight: 18 },

  optionRow: { flexDirection: "row", alignItems: "center", gap: 12, justifyContent: "space-between" },
  optionIcon: { width: 40, height: 40, borderRadius: 12, alignItems: "center", justifyContent: "center", flexShrink: 0 },
  optionText_: { flex: 1 },
  optionTitle: { fontSize: 15 },
  optionSub: { fontSize: 12, marginTop: 2 },

  appsContainer: { marginTop: 16, borderTopWidth: StyleSheet.hairlineWidth, paddingTop: 8 },
  appsHint: { fontSize: 12, marginBottom: 8, textAlign: "center" },
  appCard: {
    flexDirection: "row",
    alignItems: "center",
    paddingVertical: 12,
    paddingHorizontal: 4,
    gap: 12,
    borderRadius: 12,
  },
  appIconWrap: { borderRadius: 12, overflow: "hidden" },
  appCardInfo: { flex: 1 },
  appCardName: { fontSize: 14 },
  appCardUsage: { fontSize: 11, marginTop: 1 },
  limitChip: {
    flexDirection: "row",
    alignItems: "center",
    gap: 4,
    paddingHorizontal: 10,
    paddingVertical: 7,
    borderRadius: 12,
  },
  limitChipText: { fontSize: 13 },

  sectionHeaderRow: { flexDirection: "row", alignItems: "center", gap: 12, marginBottom: 14 },

  blurFlowRow: { flexDirection: "row", alignItems: "center", gap: 6, marginTop: 14, marginBottom: 14, flexWrap: "wrap" },
  flowChip: { paddingHorizontal: 10, paddingVertical: 5, borderRadius: 8 },
  flowChipText: { fontSize: 11 },
  demoBtn: { flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 8, paddingVertical: 13, borderRadius: 14 },
  demoBtnText: { fontSize: 14 },

  notifRow: { flexDirection: "row", alignItems: "center", gap: 10, paddingVertical: 12, borderTopWidth: StyleSheet.hairlineWidth },
  notifDot: { width: 9, height: 9, borderRadius: 5 },
  notifPct: { fontSize: 14, width: 40 },
  notifLabel: { flex: 1, fontSize: 12, lineHeight: 18 },

  modalOverlay: { flex: 1, justifyContent: "flex-end", backgroundColor: "rgba(0,0,0,0.45)" },
  sheet: { borderTopLeftRadius: 28, borderTopRightRadius: 28, borderWidth: 1, padding: 24, gap: 20 },
  sheetHandle: { width: 40, height: 4, borderRadius: 2, alignSelf: "center" },
  sheetHeader: { flexDirection: "row", alignItems: "center", gap: 14 },
  sheetTitle: { fontSize: 18 },
  sheetSub: { fontSize: 12, marginTop: 2 },
  pickerGrid: { flexDirection: "row", flexWrap: "wrap", gap: 10 },
  pickerChip: { paddingHorizontal: 20, paddingVertical: 12, borderRadius: 14, flexDirection: "row", alignItems: "center", gap: 6 },
  pickerChipText: { fontSize: 15 },
});

import { LinearGradient } from "expo-linear-gradient";
import React, { useState } from "react";
import {
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from "react-native";
import { Feather } from "@expo/vector-icons";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { BarChart } from "@/components/BarChart";
import { AppIconSVG } from "@/components/AppIconSVG";
import {
  appUsageList,
  dailyStats,
  formatMinutes,
  leastUsedApps,
  mostUsedApps,
  todayBarData,
  weekBarData,
} from "@/data/mockData";

// ─── Light theme palette ──────────────────────────────────────────────────────
const BG = "#F5F3FF";
const CARD = "#FFFFFF";
const CARD2 = "#FAFAFF";
const BORDER = "#EAE7F8";
const MUTED_FG = "#7B78A8";
const FORE = "#1A1535";
const ACCENT1 = "#8B5CF6";
const ACCENT2 = "#3B82F6";
const ACCENT3 = "#00D4AA";

type Period = "today" | "week";

export default function AnalyticsScreen() {
  const insets = useSafeAreaInsets();
  const isWeb = Platform.OS === "web";
  const topPad = isWeb ? 67 : insets.top;
  const [period, setPeriod] = useState<Period>("today");

  const totalMinutes =
    period === "today"
      ? dailyStats.totalMinutes
      : weekBarData.reduce((s, d) => s + d.value, 0);

  const insight =
    period === "today"
      ? "You used social media apps more today than yesterday."
      : "Your weekly usage is 12% higher than last week. Consider Focus Mode.";

  return (
    <View style={[styles.screen, { backgroundColor: BG }]}>
      {/* Header */}
      <View style={[styles.header, { paddingTop: topPad + 8, backgroundColor: BG, borderBottomColor: BORDER }]}>
        <Text style={[styles.headerTitle, { color: FORE, fontFamily: "Poppins_700Bold" }]}>
          Usage Analytics
        </Text>
      </View>

      <ScrollView
        contentContainerStyle={[
          styles.scroll,
          { paddingBottom: isWeb ? 100 : insets.bottom + 90 },
        ]}
        showsVerticalScrollIndicator={false}
      >
        {/* Hero gradient card */}
        <LinearGradient
          colors={[ACCENT1, ACCENT2, ACCENT3]}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
          style={styles.heroCard}
        >
          <Text style={[styles.heroLabel, { fontFamily: "Poppins_400Regular", color: "rgba(255,255,255,0.8)" }]}>
            {period === "today" ? "Today's Screen Time" : "This Week's Total"}
          </Text>
          <Text style={[styles.heroTime, { fontFamily: "Poppins_700Bold", color: "#fff" }]}>
            {formatMinutes(totalMinutes)}
          </Text>
          <View style={styles.insightRow}>
            <Feather name="cpu" size={13} color="rgba(255,255,255,0.85)" />
            <Text style={[styles.insightText, { fontFamily: "Poppins_400Regular", color: "rgba(255,255,255,0.85)" }]}>
              {insight}
            </Text>
          </View>
        </LinearGradient>

        {/* Today / This Week toggle */}
        <View style={[styles.toggleCard, { backgroundColor: CARD, borderColor: BORDER }]}>
          {(["today", "week"] as Period[]).map((p) => (
            <Pressable key={p} style={styles.toggleBtnWrap} onPress={() => setPeriod(p)}>
              {period === p ? (
                <LinearGradient
                  colors={[ACCENT1, ACCENT2]}
                  start={{ x: 0, y: 0 }}
                  end={{ x: 1, y: 0 }}
                  style={styles.toggleActive}
                >
                  <Text style={[styles.toggleText, { color: "#fff", fontFamily: "Poppins_700Bold" }]}>
                    {p === "today" ? "Today" : "This Week"}
                  </Text>
                </LinearGradient>
              ) : (
                <View style={styles.toggleInactive}>
                  <Text style={[styles.toggleText, { color: MUTED_FG, fontFamily: "Poppins_400Regular" }]}>
                    {p === "today" ? "Today" : "This Week"}
                  </Text>
                </View>
              )}
            </Pressable>
          ))}
        </View>

        {/* Bar chart card */}
        <View style={[styles.card, { backgroundColor: CARD, borderColor: BORDER }]}>
          <View style={styles.cardHeader}>
            <View style={styles.cardTitleRow}>
              <LinearGradient colors={[ACCENT1, ACCENT2]} style={styles.accentBar} />
              <Text style={[styles.cardTitle, { color: FORE, fontFamily: "Poppins_600SemiBold" }]}>
                App Usage Breakdown
              </Text>
            </View>
            <Text style={[styles.cardSub, { color: MUTED_FG, fontFamily: "Poppins_400Regular" }]}>
              {period === "today" ? "Today" : "Past 7 days"}
            </Text>
          </View>
          <BarChart key={period} data={period === "today" ? todayBarData : weekBarData} maxBarHeight={160} />
        </View>

        {/* Most Used Apps */}
        <SectionBlock label="Most Used Apps" colors={[ACCENT1, "#E1306C"]} />
        <View style={[styles.card, { backgroundColor: CARD, borderColor: BORDER, padding: 0, overflow: "hidden" }]}>
          {mostUsedApps.map((app, i) => (
            <AppRow
              key={app.id}
              app={app}
              isLast={i === mostUsedApps.length - 1}
              total={totalMinutes}
              period={period}
            />
          ))}
        </View>

        {/* Least Used Apps */}
        <SectionBlock label="Least Used Apps" colors={[ACCENT3, ACCENT2]} />
        <View style={[styles.card, { backgroundColor: CARD, borderColor: BORDER, padding: 0, overflow: "hidden" }]}>
          {leastUsedApps.map((app, i) => (
            <AppRow
              key={app.id}
              app={app}
              isLast={i === leastUsedApps.length - 1}
              total={totalMinutes}
              period={period}
            />
          ))}
        </View>

        {/* All Apps grid */}
        <SectionBlock label="All Apps Overview" colors={["#F59E0B", "#EF4444"]} />
        <View style={styles.gridRow}>
          {appUsageList.map((app) => {
            const mins = Math.round(app.usageMinutes * (period === "week" ? 6.5 : 1));
            return (
              <View key={app.id} style={[styles.gridCard, { backgroundColor: CARD, borderColor: BORDER }]}>
                <AppIconSVG appId={app.id} size={40} />
                <Text style={[styles.gridName, { color: FORE, fontFamily: "Poppins_600SemiBold" }]}>
                  {app.name}
                </Text>
                <Text style={[styles.gridTime, { color: app.iconColor, fontFamily: "Poppins_700Bold" }]}>
                  {formatMinutes(mins)}
                </Text>
                <View style={[styles.gridTrack, { backgroundColor: BORDER }]}>
                  <LinearGradient
                    colors={[app.iconColor + "90", app.iconColor]}
                    start={{ x: 0, y: 0 }}
                    end={{ x: 1, y: 0 }}
                    style={[styles.gridFill, { width: `${Math.min(app.percentageOfDay, 100)}%` }]}
                  />
                </View>
              </View>
            );
          })}
        </View>

        {/* AI Analysis */}
        <View style={[styles.card, { backgroundColor: CARD2, borderColor: BORDER }]}>
          <View style={styles.aiHeaderRow}>
            <LinearGradient colors={[ACCENT1, ACCENT3]} style={styles.aiIconBox}>
              <Feather name="cpu" size={15} color="#fff" />
            </LinearGradient>
            <Text style={[styles.cardTitle, { color: FORE, fontFamily: "Poppins_600SemiBold" }]}>
              AI Analysis
            </Text>
          </View>
          {[
            { icon: "zap", text: "Peak usage between 8–10 PM. Enable Focus Mode during this window.", color: ACCENT1 },
            { icon: "trending-up", text: "Instagram is 45 min above your daily average this week.", color: "#E1306C" },
            { icon: "moon", text: "Late-night usage (after 10 PM) increased by 40% this week.", color: ACCENT2 },
          ].map((item, i) => (
            <View key={i} style={[styles.aiRow, { borderTopColor: BORDER }]}>
              <View style={[styles.aiRowIcon, { backgroundColor: item.color + "18" }]}>
                <Feather name={item.icon as any} size={13} color={item.color} />
              </View>
              <Text style={[styles.aiRowText, { color: MUTED_FG, fontFamily: "Poppins_400Regular" }]}>
                {item.text}
              </Text>
            </View>
          ))}
        </View>
      </ScrollView>
    </View>
  );
}

function SectionBlock({ label, colors }: { label: string; colors: [string, string] }) {
  return (
    <View style={styles.sectionRow}>
      <LinearGradient colors={colors} style={styles.sectionDot} />
      <Text style={[styles.sectionLabel, { color: FORE, fontFamily: "Poppins_600SemiBold" }]}>
        {label}
      </Text>
    </View>
  );
}

function AppRow({
  app,
  isLast,
  total,
  period,
}: {
  app: (typeof appUsageList)[0];
  isLast: boolean;
  total: number;
  period: Period;
}) {
  const mins = Math.round(app.usageMinutes * (period === "week" ? 6.5 : 1));
  const pct = Math.round((mins / total) * 100);
  return (
    <View style={[styles.appRow, { borderBottomColor: BORDER, borderBottomWidth: isLast ? 0 : StyleSheet.hairlineWidth }]}>
      <View style={styles.appIconWrap}>
        <AppIconSVG appId={app.id} size={46} />
      </View>
      <View style={styles.appInfo}>
        <View style={styles.appTopRow}>
          <Text style={[styles.appName, { color: FORE, fontFamily: "Poppins_600SemiBold" }]}>{app.name}</Text>
          <Text style={[styles.appTime, { color: app.iconColor, fontFamily: "Poppins_700Bold" }]}>
            {formatMinutes(mins)}
          </Text>
        </View>
        <View style={[styles.trackBg, { backgroundColor: BORDER }]}>
          <LinearGradient
            colors={[app.iconColor + "70", app.iconColor]}
            start={{ x: 0, y: 0 }}
            end={{ x: 1, y: 0 }}
            style={[styles.trackFill, { width: `${Math.min(pct, 100)}%` }]}
          />
        </View>
        <Text style={[styles.appPct, { color: MUTED_FG, fontFamily: "Poppins_400Regular" }]}>
          {pct}% of total usage
        </Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1 },
  header: { paddingHorizontal: 20, paddingBottom: 12, borderBottomWidth: StyleSheet.hairlineWidth },
  headerTitle: { fontSize: 24 },
  scroll: { paddingHorizontal: 16, paddingTop: 16, gap: 14 },

  heroCard: { borderRadius: 24, padding: 22, gap: 8 },
  heroLabel: { fontSize: 13 },
  heroTime: { fontSize: 40, lineHeight: 48 },
  insightRow: { flexDirection: "row", alignItems: "flex-start", gap: 6, marginTop: 2 },
  insightText: { flex: 1, fontSize: 12, lineHeight: 18 },

  toggleCard: { flexDirection: "row", borderRadius: 16, borderWidth: 1, padding: 4, gap: 4 },
  toggleBtnWrap: { flex: 1 },
  toggleActive: { borderRadius: 12, paddingVertical: 10, alignItems: "center" },
  toggleInactive: { borderRadius: 12, paddingVertical: 10, alignItems: "center" },
  toggleText: { fontSize: 14 },

  card: {
    borderRadius: 20,
    borderWidth: 1,
    padding: 18,
    shadowColor: "#8B5CF6",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.06,
    shadowRadius: 12,
    elevation: 2,
  },
  cardHeader: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginBottom: 16 },
  cardTitleRow: { flexDirection: "row", alignItems: "center", gap: 8 },
  accentBar: { width: 4, height: 18, borderRadius: 2 },
  cardTitle: { fontSize: 15 },
  cardSub: { fontSize: 12 },

  sectionRow: { flexDirection: "row", alignItems: "center", gap: 8 },
  sectionDot: { width: 12, height: 12, borderRadius: 4 },
  sectionLabel: { fontSize: 16 },

  appRow: { flexDirection: "row", alignItems: "center", paddingHorizontal: 16, paddingVertical: 14, gap: 13 },
  appIconWrap: { borderRadius: 13, overflow: "hidden" },
  appInfo: { flex: 1, gap: 5 },
  appTopRow: { flexDirection: "row", justifyContent: "space-between" },
  appName: { fontSize: 14 },
  appTime: { fontSize: 14 },
  trackBg: { height: 6, borderRadius: 3, overflow: "hidden" },
  trackFill: { height: "100%", borderRadius: 3 },
  appPct: { fontSize: 11 },

  gridRow: { flexDirection: "row", flexWrap: "wrap", gap: 10 },
  gridCard: {
    width: "30%",
    flexGrow: 1,
    borderRadius: 16,
    borderWidth: 1,
    padding: 12,
    alignItems: "center",
    gap: 6,
    shadowColor: "#8B5CF6",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 8,
    elevation: 1,
  },
  gridName: { fontSize: 11, textAlign: "center" },
  gridTime: { fontSize: 13 },
  gridTrack: { width: "100%", height: 4, borderRadius: 2, overflow: "hidden" },
  gridFill: { height: "100%", borderRadius: 2 },

  aiHeaderRow: { flexDirection: "row", alignItems: "center", gap: 10, marginBottom: 14 },
  aiIconBox: { width: 34, height: 34, borderRadius: 10, alignItems: "center", justifyContent: "center" },
  aiRow: { flexDirection: "row", alignItems: "flex-start", gap: 10, paddingVertical: 11, borderTopWidth: StyleSheet.hairlineWidth },
  aiRowIcon: { width: 28, height: 28, borderRadius: 8, alignItems: "center", justifyContent: "center", flexShrink: 0 },
  aiRowText: { flex: 1, fontSize: 13, lineHeight: 19 },
});

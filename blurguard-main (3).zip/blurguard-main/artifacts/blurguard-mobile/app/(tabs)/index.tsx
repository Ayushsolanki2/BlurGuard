import React, { useEffect, useRef, useState } from "react";
import {
  View,
  Text,
  ScrollView,
  StyleSheet,
  Pressable,
  Platform,
} from "react-native";
import { Feather } from "@expo/vector-icons";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { router } from "expo-router";
import { useColors } from "@/hooks/useColors";
import { GlassCard } from "@/components/GlassCard";
import { GradientCard } from "@/components/GradientCard";
import { CircularProgress } from "@/components/CircularProgress";
import { AppUsageRow } from "@/components/AppUsageRow";
import { MotivationalPopup, getPopupTypeForPercentage, type PopupType } from "@/components/MotivationalPopup";
import { useFocus } from "@/context/FocusContext";
import {
  dailyStats,
  topApps,
  aiSuggestions,
  formatMinutes,
  getPercentage,
  getGreeting,
} from "@/data/mockData";

const percentage = getPercentage(dailyStats.totalMinutes, dailyStats.goalMinutes);
const diffMinutes = dailyStats.totalMinutes - dailyStats.yesterdayMinutes;

// Which popup to show based on usage (71% → "happy" since 50% threshold passed)
const POPUP_TYPE: PopupType = getPopupTypeForPercentage(percentage);

export default function HomeScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { isFocusModeActive, currentStreak } = useFocus();
  const isWeb = Platform.OS === "web";
  const topPad = isWeb ? 67 : insets.top;

  const [popupVisible, setPopupVisible] = useState(false);
  const hasShownPopup = useRef(false);

  // Show popup 2s after app loads (once per session)
  useEffect(() => {
    if (hasShownPopup.current) return;
    const timer = setTimeout(() => {
      hasShownPopup.current = true;
      setPopupVisible(true);
    }, 2000);
    return () => clearTimeout(timer);
  }, []);

  return (
    <View style={[styles.screen, { backgroundColor: colors.background }]}>
      <ScrollView
        contentContainerStyle={[
          styles.scroll,
          {
            paddingTop: topPad + 16,
            paddingBottom: isWeb ? 100 : insets.bottom + 90,
          },
        ]}
        showsVerticalScrollIndicator={false}
      >
        {/* Header */}
        <View style={styles.header}>
          <View>
            <Text style={[styles.greeting, { color: colors.mutedForeground, fontFamily: "Poppins_400Regular" }]}>
              {getGreeting()}
            </Text>
            <Text style={[styles.appName, { color: colors.foreground, fontFamily: "Poppins_700Bold" }]}>
              BlurGuard
            </Text>
          </View>
          <View style={styles.headerRight}>
            {isFocusModeActive && (
              <View style={[styles.focusBadge, { backgroundColor: colors.secondary + "22", borderColor: colors.secondary + "50" }]}>
                <Feather name="target" size={12} color={colors.secondary} />
                <Text style={[styles.focusBadgeText, { color: colors.secondary, fontFamily: "Poppins_600SemiBold" }]}>
                  Focus On
                </Text>
              </View>
            )}
            <Pressable
              style={[styles.streakBadge, { backgroundColor: "#F59E0B22" }]}
              onPress={() => setPopupVisible(true)}
            >
              <Feather name="zap" size={14} color="#F59E0B" />
              <Text style={[styles.streakText, { color: "#F59E0B", fontFamily: "Poppins_700Bold" }]}>
                {currentStreak}
              </Text>
            </Pressable>
          </View>
        </View>

        {/* Hero gradient card */}
        <GradientCard
          colors={[colors.gradientStart, colors.gradientMid, colors.gradientEnd]}
          borderRadius={28}
          padding={24}
          style={styles.heroCard}
        >
          <Text style={[styles.heroLabel, { color: "rgba(255,255,255,0.75)", fontFamily: "Poppins_400Regular" }]}>
            Your Daily Usage
          </Text>
          <View style={styles.heroRow}>
            <View style={styles.heroLeft}>
              <Text style={[styles.heroTime, { color: "#fff", fontFamily: "Poppins_700Bold" }]}>
                {formatMinutes(dailyStats.totalMinutes)}
              </Text>
              <View style={styles.diffRow}>
                <Feather name="arrow-up" size={13} color="rgba(255,255,255,0.8)" />
                <Text style={[styles.diffText, { color: "rgba(255,255,255,0.8)", fontFamily: "Poppins_400Regular" }]}>
                  {diffMinutes}m more than yesterday
                </Text>
              </View>
              <View style={[styles.limitPill, { backgroundColor: "rgba(255,255,255,0.2)" }]}>
                <Feather name="alert-circle" size={12} color="#fff" />
                <Text style={[styles.limitPillText, { color: "#fff", fontFamily: "Poppins_400Regular" }]}>
                  {percentage}% of {formatMinutes(dailyStats.goalMinutes)} goal
                </Text>
              </View>
            </View>
            <CircularProgress percentage={percentage} size={110} strokeWidth={10} label="" />
          </View>
        </GradientCard>

        {/* Popup hint button */}
        <Pressable
          style={[styles.popupHintRow, { backgroundColor: colors.muted, borderColor: colors.border }]}
          onPress={() => setPopupVisible(true)}
        >
          <View style={[styles.popupHintDot, { backgroundColor: POPUP_TYPE === "happy" ? "#00D4AA" : POPUP_TYPE === "caution" ? "#F59E0B" : "#EF4444" }]} />
          <Text style={[styles.popupHintText, { color: colors.mutedForeground, fontFamily: "Poppins_400Regular" }]}>
            {POPUP_TYPE === "happy" ? "Nice going — you're on track" :
             POPUP_TYPE === "caution" ? "Almost at your limit" :
             POPUP_TYPE === "tired" ? "Eyes need rest — blur starting" :
             "Time's up — apps blocked"}
          </Text>
          <Feather name="bell" size={14} color={colors.mutedForeground} />
        </Pressable>

        {/* AI Insight Summary */}
        <GlassCard padding={16} borderRadius={20}>
          <View style={styles.insightRow}>
            <View style={[styles.insightIconWrap, { backgroundColor: colors.primary + "20" }]}>
              <Feather name="cpu" size={18} color={colors.primary} />
            </View>
            <View style={{ flex: 1 }}>
              <Text style={[styles.insightTitle, { color: colors.foreground, fontFamily: "Poppins_600SemiBold" }]}>
                Today's Summary
              </Text>
              <Text style={[styles.insightBody, { color: colors.mutedForeground, fontFamily: "Poppins_400Regular" }]}>
                You spent {formatMinutes(dailyStats.totalMinutes)} on your phone today — mostly on Instagram and YouTube. Try setting a 1-hour social media limit.
              </Text>
            </View>
          </View>
        </GlassCard>

        {/* Top Apps */}
        <View style={styles.section}>
          <Text style={[styles.sectionTitle, { color: colors.foreground, fontFamily: "Poppins_600SemiBold" }]}>
            Top Apps Today
          </Text>
          <GlassCard padding={14} borderRadius={20}>
            {topApps.map((item, index) => (
              <AppUsageRow key={item.id} item={item} index={index} />
            ))}
          </GlassCard>
        </View>

        {/* AI Suggestions */}
        <View style={styles.section}>
          <Text style={[styles.sectionTitle, { color: colors.foreground, fontFamily: "Poppins_600SemiBold" }]}>
            Smart Suggestions
          </Text>
          <ScrollView
            horizontal
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={styles.suggestionsScroll}
          >
            {aiSuggestions.map((s) => (
              <GradientCard
                key={s.id}
                colors={s.gradientColors as [string, string]}
                borderRadius={20}
                padding={18}
                style={styles.suggestionCard}
              >
                <View style={[styles.suggIconWrap, { backgroundColor: "rgba(255,255,255,0.2)" }]}>
                  <Feather name={s.iconName as any} size={20} color="#fff" />
                </View>
                <Text style={[styles.suggHeadline, { color: "#fff", fontFamily: "Poppins_700Bold" }]}>
                  {s.headline}
                </Text>
                <Text style={[styles.suggBody, { color: "rgba(255,255,255,0.85)", fontFamily: "Poppins_400Regular" }]}>
                  {s.body}
                </Text>
              </GradientCard>
            ))}
          </ScrollView>
        </View>

        {/* Quick Actions */}
        <View style={styles.actionsRow}>
          <Pressable
            style={({ pressed }) => [styles.actionBtn, { backgroundColor: colors.primary, opacity: pressed ? 0.85 : 1 }]}
            onPress={() => router.push("/(tabs)/focus")}
          >
            <Feather name="target" size={18} color="#fff" />
            <Text style={[styles.actionBtnText, { color: "#fff", fontFamily: "Poppins_600SemiBold" }]}>
              Focus Mode
            </Text>
          </Pressable>
          <Pressable
            style={({ pressed }) => [styles.actionBtn, { backgroundColor: colors.muted, opacity: pressed ? 0.85 : 1 }]}
            onPress={() => router.push("/(tabs)/streaks")}
          >
            <Feather name="zap" size={18} color={colors.foreground} />
            <Text style={[styles.actionBtnText, { color: colors.foreground, fontFamily: "Poppins_600SemiBold" }]}>
              Streaks
            </Text>
          </Pressable>
        </View>
      </ScrollView>

      {/* Motivational popup */}
      <MotivationalPopup
        visible={popupVisible}
        type={POPUP_TYPE}
        onDismiss={() => setPopupVisible(false)}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1 },
  scroll: { paddingHorizontal: 16, gap: 16 },
  header: { flexDirection: "row", justifyContent: "space-between", alignItems: "center" },
  greeting: { fontSize: 13, lineHeight: 18 },
  appName: { fontSize: 24, lineHeight: 30 },
  headerRight: { flexDirection: "row", alignItems: "center", gap: 8 },
  focusBadge: {
    flexDirection: "row", alignItems: "center", gap: 4,
    paddingHorizontal: 10, paddingVertical: 5, borderRadius: 20, borderWidth: 1,
  },
  focusBadgeText: { fontSize: 12 },
  streakBadge: {
    flexDirection: "row", alignItems: "center", gap: 4,
    paddingHorizontal: 10, paddingVertical: 6, borderRadius: 20,
  },
  streakText: { fontSize: 14 },
  heroCard: { gap: 8 },
  heroLabel: { fontSize: 13 },
  heroRow: { flexDirection: "row", justifyContent: "space-between", alignItems: "center" },
  heroLeft: { flex: 1, gap: 8 },
  heroTime: { fontSize: 44, lineHeight: 50 },
  diffRow: { flexDirection: "row", alignItems: "center", gap: 4 },
  diffText: { fontSize: 12 },
  limitPill: {
    flexDirection: "row", alignItems: "center", gap: 6,
    alignSelf: "flex-start", paddingHorizontal: 10, paddingVertical: 5, borderRadius: 20,
  },
  limitPillText: { fontSize: 12 },
  popupHintRow: {
    flexDirection: "row", alignItems: "center", gap: 10,
    paddingHorizontal: 14, paddingVertical: 11,
    borderRadius: 14, borderWidth: 1,
  },
  popupHintDot: { width: 8, height: 8, borderRadius: 4 },
  popupHintText: { flex: 1, fontSize: 12 },
  insightRow: { flexDirection: "row", gap: 12, alignItems: "flex-start" },
  insightIconWrap: { width: 40, height: 40, borderRadius: 12, alignItems: "center", justifyContent: "center", flexShrink: 0 },
  insightTitle: { fontSize: 14, marginBottom: 4 },
  insightBody: { fontSize: 13, lineHeight: 19 },
  section: { gap: 10 },
  sectionTitle: { fontSize: 16 },
  suggestionsScroll: { gap: 12, paddingRight: 4 },
  suggestionCard: { width: 220, gap: 10 },
  suggIconWrap: { width: 40, height: 40, borderRadius: 12, alignItems: "center", justifyContent: "center" },
  suggHeadline: { fontSize: 15, lineHeight: 22 },
  suggBody: { fontSize: 12, lineHeight: 18 },
  actionsRow: { flexDirection: "row", gap: 12 },
  actionBtn: {
    flex: 1, flexDirection: "row", alignItems: "center", justifyContent: "center",
    gap: 8, paddingVertical: 15, borderRadius: 18,
  },
  actionBtnText: { fontSize: 15 },
});

import { LinearGradient } from "expo-linear-gradient";
import React, { useEffect, useRef, useState } from "react";
import {
  Animated,
  Easing,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from "react-native";
import Svg, { Circle } from "react-native-svg";
import { Feather } from "@expo/vector-icons";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useColors } from "@/hooks/useColors";
import { GlassCard } from "@/components/GlassCard";
import { SpendPointsModal } from "@/components/SpendPointsModal";
import { useFocus } from "@/context/FocusContext";
import {
  achievementBadges,
  leaderboard,
  strikeHistory,
  todayGoals,
  type StreakGoal,
} from "@/data/mockData";

const WEEKLY_STREAK = [true, true, true, true, true, false, false];
const WEEK_LABELS = ["M", "T", "W", "T", "F", "S", "S"];
const RING_SIZE = 160;
const RING_STROKE = 14;
const RING_RADIUS = (RING_SIZE - RING_STROKE) / 2;
const RING_CIRC = 2 * Math.PI * RING_RADIUS;

const STATUS_COLORS = {
  safe: "#00D4AA",
  caution: "#F59E0B",
  danger: "#EF4444",
};
const STATUS_LABELS = {
  safe: "You're on track",
  caution: "Near your limit",
  danger: "Limit exceeded",
};
const STATUS_SUGGESTIONS = {
  safe: "Great job! You stayed within your limits today.",
  caution: "You are close to crossing your limit. Use Focus Mode to earn more points.",
  danger: "Limit crossed. Enable Focus Mode now to reduce further point loss.",
};

function useCountUp(target: number, duration = 1400) {
  const [display, setDisplay] = useState(0);
  useEffect(() => {
    const steps = 60;
    const increment = target / steps;
    const interval = duration / steps;
    let current = 0;
    let count = 0;
    const timer = setInterval(() => {
      count++;
      current += increment;
      if (count >= steps) {
        setDisplay(target);
        clearInterval(timer);
      } else {
        setDisplay(Math.floor(current));
      }
    }, interval);
    return () => clearInterval(timer);
  }, [target]);
  return display;
}

export default function StreaksScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const isWeb = Platform.OS === "web";
  const topPad = isWeb ? 67 : insets.top;
  const {
    currentStreak,
    strikePoints,
    strikePointsToday,
    strikeStatus,
    extraMinutesUnlocked,
    spendStrikePoints,
  } = useFocus();

  const [goals, setGoals] = useState<StreakGoal[]>(todayGoals);
  const [spendModalVisible, setSpendModalVisible] = useState(false);

  const displayPoints = useCountUp(strikePoints);
  const displayToday = useCountUp(strikePointsToday > 0 ? strikePointsToday : 0);

  const ringAnim = useRef(new Animated.Value(0)).current;
  const glowAnim = useRef(new Animated.Value(0.6)).current;

  const usagePct = 71;
  const ringDash = RING_CIRC * (1 - usagePct / 100);

  useEffect(() => {
    Animated.timing(ringAnim, {
      toValue: ringDash,
      duration: 1200,
      easing: Easing.out(Easing.cubic),
      useNativeDriver: false,
    }).start();
    Animated.loop(
      Animated.sequence([
        Animated.timing(glowAnim, { toValue: 1, duration: 1200, useNativeDriver: false }),
        Animated.timing(glowAnim, { toValue: 0.55, duration: 1200, useNativeDriver: false }),
      ])
    ).start();
  }, []);

  const statusColor = STATUS_COLORS[strikeStatus];
  const completedCount = goals.filter((g) => g.completed).length;

  const toggleGoal = (id: string) => {
    setGoals((prev) => prev.map((g) => (g.id === id ? { ...g, completed: !g.completed } : g)));
  };

  return (
    <View style={[styles.screen, { backgroundColor: colors.background }]}>
      <View
        style={[
          styles.header,
          { paddingTop: topPad + 8, backgroundColor: colors.background, borderBottomColor: colors.border },
        ]}
      >
        <Text style={[styles.headerTitle, { color: colors.foreground, fontFamily: "Poppins_700Bold" }]}>
          Streaks
        </Text>
      </View>

      <ScrollView
        contentContainerStyle={[styles.scroll, { paddingBottom: isWeb ? 100 : insets.bottom + 90 }]}
        showsVerticalScrollIndicator={false}
      >
        {/* Strike Points Hero */}
        <GlassCard padding={0} borderRadius={28} style={{ overflow: "hidden" }}>
          <LinearGradient
            colors={[colors.gradientStart + "22", colors.gradientMid + "11"]}
            style={styles.strikeHero}
          >
            {/* Top row: streak + points today */}
            <View style={styles.strikeTopRow}>
              <View style={styles.streakPill}>
                <Feather name="zap" size={14} color="#F59E0B" />
                <Text style={[styles.streakPillText, { color: "#F59E0B", fontFamily: "Poppins_700Bold" }]}>
                  {currentStreak} day streak
                </Text>
              </View>
              <View style={[styles.todayPts, { backgroundColor: statusColor + "20" }]}>
                <Text style={[styles.todayPtsText, { color: statusColor, fontFamily: "Poppins_700Bold" }]}>
                  {strikePointsToday > 0 ? "+" : ""}{strikePointsToday} today
                </Text>
              </View>
            </View>

            {/* Center: ring + points */}
            <View style={styles.ringRow}>
              {/* Animated ring */}
              <View style={styles.ringWrap}>
                <Animated.View
                  style={[styles.glowRing, { shadowColor: statusColor, opacity: glowAnim }]}
                />
                <Svg width={RING_SIZE} height={RING_SIZE}>
                  <Circle
                    cx={RING_SIZE / 2}
                    cy={RING_SIZE / 2}
                    r={RING_RADIUS}
                    stroke={colors.border}
                    strokeWidth={RING_STROKE}
                    fill="none"
                  />
                  <AnimatedCircle
                    cx={RING_SIZE / 2}
                    cy={RING_SIZE / 2}
                    r={RING_RADIUS}
                    stroke={statusColor}
                    strokeWidth={RING_STROKE}
                    fill="none"
                    strokeDasharray={RING_CIRC}
                    strokeDashoffset={ringAnim}
                    strokeLinecap="round"
                    rotation={-90}
                    origin={`${RING_SIZE / 2}, ${RING_SIZE / 2}`}
                  />
                </Svg>
                <View style={styles.ringCenter}>
                  <Text style={[styles.ringPct, { color: statusColor, fontFamily: "Poppins_700Bold" }]}>
                    {usagePct}%
                  </Text>
                  <Text style={[styles.ringLabel, { color: colors.mutedForeground, fontFamily: "Poppins_400Regular" }]}>
                    of limit used
                  </Text>
                </View>
              </View>

              {/* Right side: points */}
              <View style={styles.pointsBlock}>
                <Text style={[styles.pointsSmLabel, { color: colors.mutedForeground, fontFamily: "Poppins_400Regular" }]}>
                  Strike Points
                </Text>
                <Text style={[styles.pointsBig, { color: colors.foreground, fontFamily: "Poppins_700Bold" }]}>
                  {displayPoints}
                </Text>
                <View style={[styles.statusBadge, { backgroundColor: statusColor + "20", borderColor: statusColor + "50" }]}>
                  <View style={[styles.statusDot, { backgroundColor: statusColor }]} />
                  <Text style={[styles.statusLabel, { color: statusColor, fontFamily: "Poppins_600SemiBold" }]}>
                    {STATUS_LABELS[strikeStatus]}
                  </Text>
                </View>
                {extraMinutesUnlocked > 0 && (
                  <Text style={[styles.extraTime, { color: colors.secondary, fontFamily: "Poppins_400Regular" }]}>
                    +{extraMinutesUnlocked}m unlocked
                  </Text>
                )}
              </View>
            </View>

            {/* AI suggestion */}
            <View style={[styles.aiRow, { backgroundColor: statusColor + "12", borderColor: statusColor + "30" }]}>
              <Feather name="cpu" size={13} color={statusColor} />
              <Text style={[styles.aiText, { color: colors.mutedForeground, fontFamily: "Poppins_400Regular" }]}>
                {STATUS_SUGGESTIONS[strikeStatus]}
              </Text>
            </View>

            {/* Spend points button */}
            <Pressable
              onPress={() => setSpendModalVisible(true)}
              style={({ pressed }) => [{ opacity: pressed ? 0.8 : 1 }]}
            >
              <LinearGradient
                colors={[colors.gradientStart, colors.gradientMid]}
                start={{ x: 0, y: 0 }}
                end={{ x: 1, y: 0 }}
                style={styles.spendBtn}
              >
                <Feather name="unlock" size={17} color="#fff" />
                <Text style={[styles.spendBtnText, { color: "#fff", fontFamily: "Poppins_700Bold" }]}>
                  Use Points for More Time
                </Text>
              </LinearGradient>
            </Pressable>
          </LinearGradient>
        </GlassCard>

        {/* Strike Points Rules */}
        <GlassCard padding={18} borderRadius={20}>
          <View style={styles.rulesHeader}>
            <View style={[styles.rulesIcon, { backgroundColor: colors.primary + "20" }]}>
              <Feather name="award" size={16} color={colors.primary} />
            </View>
            <Text style={[styles.rulesTitle, { color: colors.foreground, fontFamily: "Poppins_600SemiBold" }]}>
              How Strike Points Work
            </Text>
          </View>
          <View style={styles.rulesRows}>
            {[
              { icon: "check-circle", label: "Stay well within limit", pts: "+10", color: STATUS_COLORS.safe },
              { icon: "alert-circle", label: "Near limit (75–100%)", pts: "+3", color: STATUS_COLORS.caution },
              { icon: "x-circle", label: "Cross the limit", pts: "−5", color: STATUS_COLORS.danger },
            ].map((rule, i) => (
              <View key={i} style={[styles.ruleRow, { borderBottomColor: colors.border, borderBottomWidth: i < 2 ? StyleSheet.hairlineWidth : 0 }]}>
                <View style={[styles.ruleIcon, { backgroundColor: rule.color + "18" }]}>
                  <Feather name={rule.icon as any} size={14} color={rule.color} />
                </View>
                <Text style={[styles.ruleLabel, { color: colors.foreground, fontFamily: "Poppins_400Regular" }]}>
                  {rule.label}
                </Text>
                <Text style={[styles.rulePts, { color: rule.color, fontFamily: "Poppins_700Bold" }]}>
                  {rule.pts}
                </Text>
              </View>
            ))}
          </View>
        </GlassCard>

        {/* Weekly strike history */}
        <GlassCard padding={18} borderRadius={20}>
          <Text style={[styles.sectionTitle, { color: colors.foreground, fontFamily: "Poppins_600SemiBold", marginBottom: 14 }]}>
            This Week
          </Text>
          <View style={styles.historyRow}>
            {strikeHistory.map((day, i) => {
              const isPos = day.change > 0;
              const color = isPos ? STATUS_COLORS.safe : STATUS_COLORS.danger;
              const isActive = i < 5;
              return (
                <View key={i} style={styles.historyCol}>
                  <View style={[styles.historyBar, {
                    backgroundColor: isActive ? color + "20" : colors.muted,
                    borderColor: isActive ? color + "50" : "transparent",
                    borderWidth: 1,
                  }]}>
                    <Text style={[styles.historyChange, { color: isActive ? color : colors.mutedForeground, fontFamily: "Poppins_700Bold" }]}>
                      {isActive ? (day.change > 0 ? "+" : "") + day.change : "–"}
                    </Text>
                  </View>
                  <Text style={[styles.historyDay, { color: colors.mutedForeground, fontFamily: "Poppins_400Regular" }]}>
                    {day.label}
                  </Text>
                </View>
              );
            })}
          </View>
        </GlassCard>

        {/* Achievement Badges */}
        <View style={styles.section}>
          <Text style={[styles.sectionTitle, { color: colors.foreground, fontFamily: "Poppins_600SemiBold" }]}>
            Achievements
          </Text>
          <View style={styles.badgesGrid}>
            {achievementBadges.map((badge) => (
              <Pressable key={badge.id} style={styles.badgeWrap}>
                {badge.earned ? (
                  <LinearGradient
                    colors={badge.gradientColors}
                    style={styles.badgeCard}
                  >
                    <Feather name={badge.iconName as any} size={22} color="#fff" />
                    <Text style={[styles.badgeName, { color: "#fff", fontFamily: "Poppins_700Bold" }]}>
                      {badge.title}
                    </Text>
                    <View style={styles.badgePtsRow}>
                      <Feather name="star" size={10} color="rgba(255,255,255,0.8)" />
                      <Text style={[styles.badgePts, { color: "rgba(255,255,255,0.8)", fontFamily: "Poppins_400Regular" }]}>
                        +{badge.points}
                      </Text>
                    </View>
                  </LinearGradient>
                ) : (
                  <View style={[styles.badgeCard, { backgroundColor: colors.muted, borderColor: colors.border, borderWidth: 1 }]}>
                    <Feather name="lock" size={22} color={colors.mutedForeground} />
                    <Text style={[styles.badgeName, { color: colors.mutedForeground, fontFamily: "Poppins_400Regular" }]}>
                      {badge.title}
                    </Text>
                    <Text style={[styles.badgeDesc, { color: colors.mutedForeground, fontFamily: "Poppins_400Regular" }]}>
                      {badge.description}
                    </Text>
                  </View>
                )}
              </Pressable>
            ))}
          </View>
        </View>

        {/* Weekly streak dots */}
        <GlassCard padding={20} borderRadius={20}>
          <Text style={[styles.sectionTitle, { color: colors.foreground, fontFamily: "Poppins_600SemiBold", marginBottom: 14 }]}>
            Streak Calendar
          </Text>
          <View style={styles.weekRow}>
            {WEEK_LABELS.map((label, i) => (
              <View key={i} style={styles.dayItem}>
                <View style={[styles.dayDot, { backgroundColor: WEEKLY_STREAK[i] ? colors.secondary : colors.muted }]}>
                  {WEEKLY_STREAK[i] && <Feather name="check" size={11} color="#fff" />}
                </View>
                <Text style={[styles.dayLabel, { color: colors.mutedForeground, fontFamily: "Poppins_400Regular" }]}>
                  {label}
                </Text>
              </View>
            ))}
          </View>
        </GlassCard>

        {/* Goals */}
        <View style={styles.section}>
          <Text style={[styles.sectionTitle, { color: colors.foreground, fontFamily: "Poppins_600SemiBold" }]}>
            Today's Goals
          </Text>
          <GlassCard padding={16} borderRadius={20}>
            {goals.map((goal, i) => (
              <Pressable
                key={goal.id}
                style={[styles.goalRow, { borderBottomColor: colors.border, borderBottomWidth: i < goals.length - 1 ? StyleSheet.hairlineWidth : 0 }]}
                onPress={() => toggleGoal(goal.id)}
              >
                <View style={[styles.goalCheck, { backgroundColor: goal.completed ? colors.secondary : colors.muted, borderColor: goal.completed ? colors.secondary : colors.border }]}>
                  {goal.completed && <Feather name="check" size={12} color="#fff" />}
                </View>
                <View style={[styles.goalIconWrap, { backgroundColor: colors.primary + "15" }]}>
                  <Feather name={goal.iconName as any} size={14} color={colors.primary} />
                </View>
                <Text style={[styles.goalLabel, { color: goal.completed ? colors.mutedForeground : colors.foreground, fontFamily: "Poppins_400Regular", textDecorationLine: goal.completed ? "line-through" : "none" }]}>
                  {goal.label}
                </Text>
                {goal.completed && (
                  <View style={[styles.goalPts, { backgroundColor: colors.secondary + "20" }]}>
                    <Text style={[styles.goalPtsText, { color: colors.secondary, fontFamily: "Poppins_700Bold" }]}>+10</Text>
                  </View>
                )}
              </Pressable>
            ))}
          </GlassCard>
        </View>

        {/* Leaderboard */}
        <View style={styles.section}>
          <Text style={[styles.sectionTitle, { color: colors.foreground, fontFamily: "Poppins_600SemiBold" }]}>
            Leaderboard
          </Text>
          <GlassCard padding={14} borderRadius={20} style={{ gap: 0 }}>
            {leaderboard.map((entry, i) => (
              <View
                key={entry.id}
                style={[
                  styles.leaderRow,
                  { borderBottomColor: colors.border, backgroundColor: entry.isCurrentUser ? colors.primary + "12" : "transparent", borderBottomWidth: i < leaderboard.length - 1 ? StyleSheet.hairlineWidth : 0 },
                ]}
              >
                {entry.rank <= 2 ? (
                  <LinearGradient colors={entry.rank === 1 ? ["#F59E0B", "#EF4444"] : ["#9CA3AF", "#6B7280"]} style={styles.rankBadge}>
                    <Text style={[styles.rankNum, { color: "#fff", fontFamily: "Poppins_700Bold" }]}>{entry.rank}</Text>
                  </LinearGradient>
                ) : (
                  <Text style={[styles.rankNumPlain, { color: colors.mutedForeground, fontFamily: "Poppins_700Bold" }]}>{entry.rank}</Text>
                )}
                <View style={[styles.leaderAvatar, { backgroundColor: entry.avatarColor + "30" }]}>
                  <Text style={[styles.leaderAvatarLetter, { color: entry.avatarColor, fontFamily: "Poppins_700Bold" }]}>{entry.avatarLetter}</Text>
                </View>
                <Text style={[styles.leaderName, { color: entry.isCurrentUser ? colors.primary : colors.foreground, fontFamily: entry.isCurrentUser ? "Poppins_700Bold" : "Poppins_400Regular" }]}>
                  {entry.name}
                </Text>
                <View style={[styles.leaderPts, { backgroundColor: colors.muted }]}>
                  <Feather name="star" size={11} color={colors.mutedForeground} />
                  <Text style={[styles.leaderPtsText, { color: colors.foreground, fontFamily: "Poppins_700Bold" }]}>{entry.points.toLocaleString()}</Text>
                </View>
              </View>
            ))}
          </GlassCard>
        </View>
      </ScrollView>

      <SpendPointsModal
        visible={spendModalVisible}
        currentPoints={strikePoints}
        onClose={() => setSpendModalVisible(false)}
        onSpend={spendStrikePoints}
      />
    </View>
  );
}

// Animated Circle wrapper
const AnimatedCircle = Animated.createAnimatedComponent(Circle);

const styles = StyleSheet.create({
  screen: { flex: 1 },
  header: { paddingHorizontal: 20, paddingBottom: 12, borderBottomWidth: StyleSheet.hairlineWidth },
  headerTitle: { fontSize: 24, lineHeight: 32 },
  scroll: { paddingHorizontal: 16, paddingTop: 16, gap: 16 },
  section: { gap: 10 },
  sectionTitle: { fontSize: 16 },

  strikeHero: { padding: 20, gap: 18, borderRadius: 28 },
  strikeTopRow: { flexDirection: "row", justifyContent: "space-between", alignItems: "center" },
  streakPill: { flexDirection: "row", alignItems: "center", gap: 5, backgroundColor: "#F59E0B22", borderRadius: 20, paddingHorizontal: 10, paddingVertical: 5 },
  streakPillText: { fontSize: 13 },
  todayPts: { paddingHorizontal: 10, paddingVertical: 5, borderRadius: 20 },
  todayPtsText: { fontSize: 13 },

  ringRow: { flexDirection: "row", alignItems: "center", justifyContent: "space-between" },
  ringWrap: { width: RING_SIZE, height: RING_SIZE, alignItems: "center", justifyContent: "center" },
  glowRing: {
    position: "absolute",
    width: RING_SIZE - 20,
    height: RING_SIZE - 20,
    borderRadius: (RING_SIZE - 20) / 2,
    shadowOffset: { width: 0, height: 0 },
    shadowRadius: 24,
    shadowOpacity: 0.6,
    elevation: 12,
  },
  ringCenter: { position: "absolute", alignItems: "center" },
  ringPct: { fontSize: 28, lineHeight: 34 },
  ringLabel: { fontSize: 11, marginTop: 2 },

  pointsBlock: { flex: 1, alignItems: "flex-end", gap: 8 },
  pointsSmLabel: { fontSize: 12 },
  pointsBig: { fontSize: 52, lineHeight: 60 },
  statusBadge: { flexDirection: "row", alignItems: "center", gap: 6, paddingHorizontal: 10, paddingVertical: 5, borderRadius: 20, borderWidth: 1 },
  statusDot: { width: 7, height: 7, borderRadius: 4 },
  statusLabel: { fontSize: 11 },
  extraTime: { fontSize: 12, marginTop: 2 },

  aiRow: { flexDirection: "row", alignItems: "flex-start", gap: 8, padding: 12, borderRadius: 12, borderWidth: 1 },
  aiText: { flex: 1, fontSize: 12, lineHeight: 18 },

  spendBtn: { flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 8, paddingVertical: 14, borderRadius: 16 },
  spendBtnText: { fontSize: 15 },

  rulesHeader: { flexDirection: "row", alignItems: "center", gap: 10, marginBottom: 14 },
  rulesIcon: { width: 36, height: 36, borderRadius: 10, alignItems: "center", justifyContent: "center" },
  rulesTitle: { fontSize: 15 },
  rulesRows: { gap: 0 },
  ruleRow: { flexDirection: "row", alignItems: "center", gap: 10, paddingVertical: 12 },
  ruleIcon: { width: 30, height: 30, borderRadius: 9, alignItems: "center", justifyContent: "center" },
  ruleLabel: { flex: 1, fontSize: 13 },
  rulePts: { fontSize: 15 },

  historyRow: { flexDirection: "row", justifyContent: "space-between" },
  historyCol: { alignItems: "center", gap: 6 },
  historyBar: { width: 38, height: 38, borderRadius: 12, alignItems: "center", justifyContent: "center" },
  historyChange: { fontSize: 12 },
  historyDay: { fontSize: 11 },

  badgesGrid: { flexDirection: "row", flexWrap: "wrap", gap: 10 },
  badgeWrap: { width: "47%" },
  badgeCard: { borderRadius: 18, padding: 16, gap: 6, alignItems: "flex-start" },
  badgeName: { fontSize: 13, lineHeight: 18 },
  badgePtsRow: { flexDirection: "row", alignItems: "center", gap: 4, marginTop: 2 },
  badgePts: { fontSize: 12 },
  badgeDesc: { fontSize: 11, lineHeight: 16 },

  weekRow: { flexDirection: "row", justifyContent: "space-between" },
  dayItem: { alignItems: "center", gap: 5 },
  dayDot: { width: 30, height: 30, borderRadius: 15, alignItems: "center", justifyContent: "center" },
  dayLabel: { fontSize: 11 },

  goalRow: { flexDirection: "row", alignItems: "center", paddingVertical: 13, gap: 10 },
  goalCheck: { width: 22, height: 22, borderRadius: 11, borderWidth: 1.5, alignItems: "center", justifyContent: "center" },
  goalIconWrap: { width: 30, height: 30, borderRadius: 9, alignItems: "center", justifyContent: "center" },
  goalLabel: { flex: 1, fontSize: 13, lineHeight: 19 },
  goalPts: { paddingHorizontal: 8, paddingVertical: 3, borderRadius: 8 },
  goalPtsText: { fontSize: 12 },

  leaderRow: { flexDirection: "row", alignItems: "center", paddingVertical: 13, paddingHorizontal: 4, gap: 10, borderRadius: 12 },
  rankBadge: { width: 26, height: 26, borderRadius: 9, alignItems: "center", justifyContent: "center" },
  rankNum: { fontSize: 13 },
  rankNumPlain: { fontSize: 15, width: 26, textAlign: "center" },
  leaderAvatar: { width: 38, height: 38, borderRadius: 12, alignItems: "center", justifyContent: "center" },
  leaderAvatarLetter: { fontSize: 15 },
  leaderName: { flex: 1, fontSize: 14 },
  leaderPts: { flexDirection: "row", alignItems: "center", gap: 4, paddingHorizontal: 10, paddingVertical: 5, borderRadius: 10 },
  leaderPtsText: { fontSize: 13 },
});

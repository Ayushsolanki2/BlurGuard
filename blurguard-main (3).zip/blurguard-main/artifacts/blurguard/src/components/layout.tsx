import { Shield, Sun, Moon, Home, BarChart2 } from "lucide-react";
import { Link, useLocation } from "wouter";
import { useTheme } from "./theme-provider";
import { motion } from "framer-motion";

export function Layout({ children }: { children: React.ReactNode }) {
  const { theme, setTheme } = useTheme();
  const [location] = useLocation();

  const toggleTheme = () => {
    setTheme(theme === "dark" ? "light" : "dark");
  };

  const today = new Date().toLocaleDateString("en-US", {
    weekday: "long",
    month: "long",
    day: "numeric",
  });

  return (
    <div className="min-h-[100dvh] w-full flex justify-center bg-black dark:bg-[#06060D] transition-colors duration-300 relative overflow-hidden">
      {/* Background gradients for vibe */}
      <div className="fixed top-0 left-0 w-full h-full pointer-events-none opacity-40 dark:opacity-30">
        <div className="absolute top-[-10%] left-[-10%] w-[50%] h-[40%] bg-primary/30 blur-[100px] rounded-full" />
        <div className="absolute top-[20%] right-[-10%] w-[40%] h-[30%] bg-secondary/20 blur-[100px] rounded-full" />
      </div>

      <div className="w-full max-w-[430px] min-h-[100dvh] flex flex-col relative z-10 shadow-2xl shadow-black/50 bg-background/90 dark:bg-background/80 backdrop-blur-xl">
        {/* Top App Bar */}
        <header className="sticky top-0 z-50 flex items-center justify-between px-6 py-4 bg-background/50 backdrop-blur-md border-b border-border/50">
          <div className="flex flex-col">
            <div className="flex items-center gap-2">
              <Shield className="w-5 h-5 text-primary" />
              <h1 className="font-semibold text-lg tracking-tight">BlurGuard</h1>
            </div>
            <p className="text-xs text-muted-foreground">{today}</p>
          </div>
          <button
            onClick={toggleTheme}
            className="p-2 rounded-full hover:bg-muted/50 transition-colors"
          >
            {theme === "dark" ? (
              <Sun className="w-5 h-5 text-muted-foreground" />
            ) : (
              <Moon className="w-5 h-5 text-muted-foreground" />
            )}
          </button>
        </header>

        {/* Main Content Area */}
        <main className="flex-1 overflow-y-auto pb-24 px-6 pt-4 space-y-6 scroll-smooth">
          {children}
        </main>

        {/* Bottom Navigation */}
        <nav className="fixed bottom-0 w-full max-w-[430px] z-50 pb-safe">
          <div className="mx-4 mb-4 px-2 py-3 bg-card/80 backdrop-blur-xl border border-card-border rounded-3xl flex justify-around items-center shadow-lg">
            <Link href="/">
              <div className="flex flex-col items-center justify-center w-16 h-12 relative cursor-pointer">
                {location === "/" && (
                  <motion.div
                    layoutId="nav-indicator"
                    className="absolute inset-0 bg-gradient-to-tr from-primary/20 to-secondary/20 rounded-2xl z-0"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                  />
                )}
                <Home
                  className={`w-6 h-6 z-10 ${
                    location === "/" ? "text-primary" : "text-muted-foreground"
                  }`}
                />
                <span
                  className={`text-[10px] mt-1 z-10 font-medium ${
                    location === "/" ? "text-primary" : "text-muted-foreground"
                  }`}
                >
                  Home
                </span>
              </div>
            </Link>
            <Link href="/analytics">
              <div className="flex flex-col items-center justify-center w-16 h-12 relative cursor-pointer">
                {location === "/analytics" && (
                  <motion.div
                    layoutId="nav-indicator"
                    className="absolute inset-0 bg-gradient-to-tr from-primary/20 to-secondary/20 rounded-2xl z-0"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                  />
                )}
                <BarChart2
                  className={`w-6 h-6 z-10 ${
                    location === "/analytics"
                      ? "text-primary"
                      : "text-muted-foreground"
                  }`}
                />
                <span
                  className={`text-[10px] mt-1 z-10 font-medium ${
                    location === "/analytics"
                      ? "text-primary"
                      : "text-muted-foreground"
                  }`}
                >
                  Analytics
                </span>
              </div>
            </Link>
          </div>
        </nav>
      </div>
    </div>
  );
}

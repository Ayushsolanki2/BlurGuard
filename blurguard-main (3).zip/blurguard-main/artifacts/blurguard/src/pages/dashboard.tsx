import { motion } from "framer-motion";
import { AlertCircle, Clock, Smartphone, Bell, ArrowRight } from "lucide-react";
import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";

export function Dashboard() {
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    const timer = setTimeout(() => setProgress(71), 300);
    return () => clearTimeout(timer);
  }, []);

  const circumference = 2 * Math.PI * 120;
  const strokeDashoffset = circumference - (progress / 100) * circumference;

  const insights = [
    { title: "Instagram Overuse", desc: "40% of today's time", color: "border-l-chart-1", icon: AlertCircle, iconColor: "text-chart-1" },
    { title: "Take a Break", desc: "2h uninterrupted", color: "border-l-chart-2", icon: Clock, iconColor: "text-chart-2" },
    { title: "Late Night", desc: "1h past bedtime", color: "border-l-chart-3", icon: Bell, iconColor: "text-chart-3" },
    { title: "Focus Win", desc: "3h deep work", color: "border-l-chart-4", icon: Smartphone, iconColor: "text-chart-4" },
  ];

  const apps = [
    { name: "Instagram", time: "2h 15m", percent: 40, color: "bg-chart-1", iconColor: "text-chart-1" },
    { name: "YouTube", time: "1h 30m", percent: 27, color: "bg-chart-2", iconColor: "text-chart-2" },
    { name: "WhatsApp", time: "45m", percent: 13, color: "bg-chart-3", iconColor: "text-chart-3" },
    { name: "Chrome", time: "32m", percent: 9, color: "bg-chart-4", iconColor: "text-chart-4" },
    { name: "Spotify", time: "28m", percent: 8, color: "bg-chart-5", iconColor: "text-chart-5" },
  ];

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      className="space-y-6"
    >
      {/* Hero Card */}
      <motion.div
        className="bg-card rounded-3xl p-6 border border-card-border shadow-lg relative overflow-hidden"
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ delay: 0.1 }}
      >
        <div className="absolute -top-10 -right-10 w-32 h-32 bg-primary/20 blur-3xl rounded-full pointer-events-none" />
        <h2 className="text-muted-foreground font-medium text-sm">Today's Usage</h2>
        <div className="mt-2 flex items-baseline gap-2">
          <span className="text-4xl font-bold">5h 42m</span>
          <span className="text-xs text-muted-foreground bg-muted px-2 py-1 rounded-full">
            ↑ 23 min more
          </span>
        </div>
        
        <div className="mt-8 flex justify-center relative">
          <svg className="w-48 h-48 transform -rotate-90">
            <circle
              cx="96"
              cy="96"
              r="76"
              stroke="currentColor"
              strokeWidth="12"
              fill="transparent"
              className="text-muted/30"
            />
            <motion.circle
              cx="96"
              cy="96"
              r="76"
              stroke="url(#gradient)"
              strokeWidth="12"
              fill="transparent"
              strokeLinecap="round"
              strokeDasharray={circumference}
              initial={{ strokeDashoffset: circumference }}
              animate={{ strokeDashoffset }}
              transition={{ duration: 1.5, ease: "easeOut" }}
            />
            <defs>
              <linearGradient id="gradient" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="hsl(var(--primary))" />
                <stop offset="100%" stopColor="hsl(var(--secondary))" />
              </linearGradient>
            </defs>
          </svg>
          <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
            <span className="text-3xl font-bold">{progress}%</span>
            <span className="text-xs text-muted-foreground">of daily goal</span>
          </div>
        </div>
      </motion.div>

      {/* Quick Stats */}
      <div className="grid grid-cols-3 gap-3">
        {[
          { label: "Unlocks", val: "47" },
          { label: "Alerts", val: "132" },
          { label: "Night", val: "1h 10m" },
        ].map((stat, i) => (
          <motion.div
            key={i}
            className="bg-card border border-card-border p-4 rounded-2xl flex flex-col items-center justify-center"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 + i * 0.1 }}
          >
            <span className="text-xl font-semibold">{stat.val}</span>
            <span className="text-[10px] text-muted-foreground mt-1">{stat.label}</span>
          </motion.div>
        ))}
      </div>

      {/* AI Insights (Horizontal Scroll) */}
      <div>
        <h3 className="font-semibold mb-3 text-sm">AI Insights</h3>
        <div className="flex overflow-x-auto gap-4 pb-4 -mx-6 px-6 snap-x hide-scrollbar">
          {insights.map((item, i) => (
            <motion.div
              key={i}
              className={`min-w-[160px] snap-center bg-card p-4 rounded-2xl border-y border-r border-card-border border-l-4 ${item.color}`}
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.3 + i * 0.1 }}
            >
              <item.icon className={`w-5 h-5 mb-2 ${item.iconColor}`} />
              <p className="font-medium text-sm">{item.title}</p>
              <p className="text-xs text-muted-foreground mt-1">{item.desc}</p>
            </motion.div>
          ))}
        </div>
      </div>

      {/* Most Used Apps */}
      <div className="bg-card rounded-3xl p-6 border border-card-border">
        <h3 className="font-semibold mb-4 text-sm">Most Used Apps</h3>
        <div className="space-y-5">
          {apps.map((app, i) => (
            <motion.div
              key={app.name}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.4 + i * 0.1 }}
            >
              <div className="flex justify-between items-center mb-2">
                <div className="flex items-center gap-3">
                  <div className={`w-8 h-8 rounded-full ${app.color}/20 flex items-center justify-center`}>
                    <span className={`font-bold text-xs ${app.iconColor}`}>{app.name[0]}</span>
                  </div>
                  <span className="text-sm font-medium">{app.name}</span>
                </div>
                <span className="text-xs font-semibold">{app.time}</span>
              </div>
              <div className="w-full h-2 bg-muted rounded-full overflow-hidden">
                <motion.div
                  className={`h-full ${app.color}`}
                  initial={{ width: 0 }}
                  animate={{ width: `${app.percent}%` }}
                  transition={{ delay: 0.6 + i * 0.1, duration: 1 }}
                />
              </div>
            </motion.div>
          ))}
        </div>
      </div>

      {/* Warning Banner */}
      <motion.div
        className="bg-destructive/10 border border-destructive/20 rounded-2xl p-4 flex items-center justify-between mt-4"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 1 }}
      >
        <div className="flex items-center gap-3">
          <AlertCircle className="w-5 h-5 text-destructive" />
          <div className="text-sm">
            <p className="font-medium text-destructive">Instagram limit reached!</p>
            <p className="text-xs text-destructive/80">15 min remaining</p>
          </div>
        </div>
        <Button variant="outline" size="sm" className="text-xs h-8">Set Limit</Button>
      </motion.div>
    </motion.div>
  );
}

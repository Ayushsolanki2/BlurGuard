import { motion } from "framer-motion";
import { useState } from "react";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, LineChart, Line, PieChart, Pie, Cell } from "recharts";
import { Activity, Target, ShieldAlert } from "lucide-react";

const hourlyData = [
  { time: "6A", value: 10 },
  { time: "9A", value: 45 },
  { time: "12P", value: 60 },
  { time: "3P", value: 90 },
  { time: "6P", value: 120 },
  { time: "9P", value: 30 },
  { time: "12A", value: 15 },
];

const weeklyData = [
  { day: "M", total: 4.5, limit: 8 },
  { day: "T", total: 6.2, limit: 8 },
  { day: "W", total: 5.8, limit: 8 },
  { day: "T", total: 7.1, limit: 8 },
  { day: "F", total: 5.2, limit: 8 },
  { day: "S", total: 8.3, limit: 8 },
  { day: "S", total: 5.7, limit: 8 },
];

const pieData = [
  { name: "Instagram", value: 40, color: "hsl(var(--chart-1))" },
  { name: "YouTube", value: 27, color: "hsl(var(--chart-2))" },
  { name: "WhatsApp", value: 13, color: "hsl(var(--chart-3))" },
  { name: "Chrome", value: 9, color: "hsl(var(--chart-4))" },
  { name: "Spotify", value: 8, color: "hsl(var(--chart-5))" },
  { name: "Other", value: 3, color: "hsl(var(--muted))" },
];

export function Analytics() {
  const [tab, setTab] = useState<"Today" | "Week" | "Month">("Week");

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      className="space-y-6"
    >
      {/* Tabs */}
      <div className="flex p-1 bg-card border border-card-border rounded-xl mb-6">
        {["Today", "Week", "Month"].map((t) => (
          <button
            key={t}
            onClick={() => setTab(t as any)}
            className="flex-1 py-2 text-xs font-medium relative rounded-lg"
          >
            {tab === t && (
              <motion.div
                layoutId="analytics-tab"
                className="absolute inset-0 bg-muted rounded-lg z-0"
              />
            )}
            <span className={`relative z-10 ${tab === t ? "text-foreground" : "text-muted-foreground"}`}>{t}</span>
          </button>
        ))}
      </div>

      {/* Hourly Chart */}
      <motion.div
        className="bg-card rounded-3xl p-6 border border-card-border shadow-lg"
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
      >
        <h3 className="font-semibold mb-6 text-sm">Hourly Usage Today</h3>
        <div className="h-48 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={hourlyData}>
              <XAxis dataKey="time" axisLine={false} tickLine={false} tick={{ fontSize: 10, fill: "hsl(var(--muted-foreground))" }} />
              <Tooltip cursor={{ fill: "hsl(var(--muted))", opacity: 0.4 }} contentStyle={{ backgroundColor: "hsl(var(--card))", borderRadius: "8px", border: "1px solid hsl(var(--card-border))" }} />
              <Bar dataKey="value" fill="hsl(var(--primary))" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </motion.div>

      {/* Weekly Chart */}
      <motion.div
        className="bg-card rounded-3xl p-6 border border-card-border shadow-lg"
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ delay: 0.1 }}
      >
        <h3 className="font-semibold mb-6 text-sm">This Week's Overview</h3>
        <div className="h-48 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={weeklyData}>
              <XAxis dataKey="day" axisLine={false} tickLine={false} tick={{ fontSize: 10, fill: "hsl(var(--muted-foreground))" }} />
              <Tooltip contentStyle={{ backgroundColor: "hsl(var(--card))", borderRadius: "8px", border: "1px solid hsl(var(--card-border))" }} />
              <Line type="monotone" dataKey="limit" stroke="hsl(var(--secondary))" strokeDasharray="5 5" strokeWidth={2} dot={false} />
              <Line type="monotone" dataKey="total" stroke="hsl(var(--primary))" strokeWidth={3} activeDot={{ r: 6, fill: "hsl(var(--primary))" }} />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </motion.div>

      {/* Donut Chart */}
      <motion.div
        className="bg-card rounded-3xl p-6 border border-card-border shadow-lg flex flex-col items-center"
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ delay: 0.2 }}
      >
        <h3 className="font-semibold mb-2 text-sm w-full text-left">App Breakdown</h3>
        <div className="h-48 w-full relative flex items-center justify-center">
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie
                data={pieData}
                innerRadius={60}
                outerRadius={80}
                paddingAngle={5}
                dataKey="value"
                stroke="none"
              >
                {pieData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip contentStyle={{ backgroundColor: "hsl(var(--card))", borderRadius: "8px", border: "1px solid hsl(var(--card-border))" }} />
            </PieChart>
          </ResponsiveContainer>
          <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
            <span className="text-xl font-bold">6 Apps</span>
          </div>
        </div>
        <div className="flex flex-wrap justify-center gap-3 mt-4">
          {pieData.slice(0, 4).map((d) => (
            <div key={d.name} className="flex items-center gap-1.5 text-xs">
              <span className="w-2 h-2 rounded-full" style={{ backgroundColor: d.color }} />
              <span className="text-muted-foreground">{d.name}</span>
            </div>
          ))}
        </div>
      </motion.div>

      {/* AI Analysis Cards */}
      <div className="space-y-3 pb-8">
        <h3 className="font-semibold mb-3 text-sm px-1">AI Analysis</h3>
        {[
          { title: "Peak Usage", desc: "You use your phone most between 3 PM and 6 PM.", icon: Activity },
          { title: "WHO Recommendation", desc: "You are within healthy limits on 5 out of 7 days.", icon: Target },
          { title: "Weekend Spike", desc: "Usage increases by 40% on weekends. Try a digital detox Sunday.", icon: ShieldAlert },
        ].map((card, i) => (
          <motion.div
            key={i}
            className="bg-card p-4 rounded-2xl border border-card-border flex items-start gap-4"
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.3 + i * 0.1 }}
          >
            <div className="p-2 bg-primary/10 text-primary rounded-xl shrink-0">
              <card.icon className="w-5 h-5" />
            </div>
            <div>
              <p className="font-medium text-sm">{card.title}</p>
              <p className="text-xs text-muted-foreground mt-1 leading-relaxed">{card.desc}</p>
            </div>
          </motion.div>
        ))}
      </div>
    </motion.div>
  );
}
